#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
股票数据管理工具

整合下载和数据库功能，提供便捷的数据管理方法
"""

import os
import pandas as pd
from datetime import datetime, timedelta
import logging

from ..downloader.a_stock.a_stock_downloader import AStockDownloader
from ..downloader.hk_stock.hk_stock_downloader import HKStockDownloader
from ..downloader.us_stock.us_stock_downloader import USStockDownloader

from ..database.stock_database import StockDatabase

from ..common.logger import get_logger


class StockDataManager:
    """
    股票数据管理工具类
    
    提供股票数据下载和管理的集成功能，包括增量更新和数据验证
    """
    
    def __init__(self):
        """初始化数据管理工具"""
        # 创建下载器
        self.a_stock_downloader = AStockDownloader()
        self.hk_stock_downloader = HKStockDownloader()
        self.us_stock_downloader = USStockDownloader()
        
        # 创建统一数据库管理器
        self.stock_db = StockDatabase()
        
        # 初始化日志
        self.logger = get_logger("StockDataManager")
    
    def get_downloader(self, market_type):
        """获取指定市场的下载器"""
        if market_type.upper() == 'A':
            return self.a_stock_downloader
        elif market_type.upper() == 'HK':
            return self.hk_stock_downloader
        elif market_type.upper() == 'US':
            return self.us_stock_downloader
        else:
            raise ValueError(f"不支持的市场类型: {market_type}")
    
    def get_db_manager(self, market_type):
        """获取数据库管理器（兼容旧接口）"""
        # 这里直接返回统一的数据库管理器
        return self.stock_db
    
    def get_stock_data(self, code, market_type, start_date=None, end_date=None):
        """获取股票历史数据"""
        # 记录诊断信息
        self.logger.info(f"获取 {market_type} 市场股票 {code} 的历史数据，日期范围: {start_date} 至 {end_date}")
        
        # 处理日期参数
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        if start_date is None:
            start_date = (datetime.strptime(end_date, '%Y-%m-%d') - timedelta(days=365)).strftime('%Y-%m-%d')
        
        # 从数据库获取数据
        self.logger.info(f"尝试从数据库获取股票 {code} 的历史数据")
        data = self.stock_db.get_stock_data(code, start_date, end_date, market_type)
        
        # 检查数据记录数
        if not data.empty:
            self.logger.info(f"从数据库获取到 {code} 的历史数据，共 {len(data)} 条记录")
        
        # 如果数据为空，尝试下载
        if data.empty:
            self.logger.info(f"数据库中没有股票 {code} 数据，准备下载")
            self.update_stock_data(code, market_type, start_date, end_date)
            # 再次从数据库获取
            data = self.stock_db.get_stock_data(code, start_date, end_date, market_type)
            
            # 显示下载结果
            if data.empty:
                self.logger.warning(f"下载后仍然没有 {code} 的数据")
            else:
                self.logger.info(f"下载成功，获取到 {len(data)} 条记录")
        
        return data
    
    def update_stock_data(self, code, market_type, start_date=None, end_date=None, adjust='qfq'):
        """更新股票数据"""
        # 获取对应市场的下载器
        downloader = self.get_downloader(market_type)
        
        # 处理日期
        end_date = end_date or datetime.now().strftime('%Y-%m-%d')
        if start_date is None:
            # 获取最新的数据日期
            latest_date = self.stock_db.get_latest_date(code, market_type)
            if latest_date:
                # 从最新日期后一天开始下载
                start_date = (datetime.strptime(latest_date, '%Y-%m-%d') + timedelta(days=1)).strftime('%Y-%m-%d')
            else:
                # 如果没有数据，下载近30天的
                start_date = (datetime.strptime(end_date, '%Y-%m-%d') - timedelta(days=30)).strftime('%Y-%m-%d')
        
        self.logger.info(f"下载股票 {code} 增量数据，日期范围: {start_date} 至 {end_date}")
        
        # 下载数据
        data = downloader.download_stock_data(code, start_date, end_date, adjust)
        
        # 检查数据是否为空
        if data.empty:
            self.logger.warning(f"股票 {code} 在指定日期范围内没有新数据")
            return 0
        
        # 将数据保存到数据库
        count = self.stock_db.save_stock_data(data, market_type)
        self.logger.info(f"股票 {code} 数据下载并保存成功，共 {count} 条记录")
        
        return count
    
    def batch_update_stocks(self, stock_codes, market_type, days=30, adjust=None):
        """
        批量更新多只股票数据
        
        Args:
            stock_codes: 股票代码列表
            market_type: 市场类型，'A', 'HK', 'US'
            days: 如果没有历史数据，下载最近days天的数据
            adjust: 复权类型
            
        Returns:
            dict: 更新结果统计
        """
        result = {
            'total': len(stock_codes),
            'success': 0,
            'failed': 0,
            'skipped': 0
        }
        
        for code in stock_codes:
            try:
                updated = self.update_stock_data(code, market_type, days, adjust)
                if updated:
                    result['success'] += 1
                else:
                    result['skipped'] += 1
            except Exception as e:
                self.logger.error(f"更新股票 {code} 数据失败: {e}")
                result['failed'] += 1
        
        return result 