#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
A股数据下载器模块

负责从A股市场下载股票数据，使用akshare库实现。
"""

from .a_stock_downloader import AStockDownloader

__all__ = ['AStockDownloader']