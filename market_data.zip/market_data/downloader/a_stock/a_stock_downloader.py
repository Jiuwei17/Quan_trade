#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
A股数据下载器

负责从A股市场下载股票数据，使用akshare库实现，并提供备用数据源。
"""

import os
import time
import pandas as pd
import numpy as np
import akshare as ak
from datetime import datetime, timedelta
import pickle
import hashlib
from pathlib import Path

# 导入基类
from ..base_downloader import BaseDownloader


class AStockDownloader(BaseDownloader):
    """
    A股数据下载器
    
    负责从A股市场下载股票数据，使用akshare库实现，并提供数据验证与缓存功能。
    """
    
    # 类常量 - 列名映射字典
    COLUMN_MAPPINGS = {
        '日期': 'date',
        '开盘': 'open',
        '收盘': 'close',
        '最高': 'high',
        '最低': 'low',
        '成交量': 'volume',
        '成交额': 'amount',
        '涨跌幅': 'change_pct',
        '涨跌额': 'change',
        '换手率': 'turnover',
        '振幅': 'amplitude',
        '总市值': 'total_market_value',
        '流通市值': 'circulating_market_value',
        '成交笔数': 'transactions',
        'open': 'open',
        'close': 'close',
        'high': 'high',
        'low': 'low',
        'volume': 'volume',
        'amount': 'amount',
        'change_pct': 'change_pct',
        'change': 'change',
        'turnover': 'turnover'
    }
    
    # 必需的数据列
    REQUIRED_STOCK_COLUMNS = ['open', 'close', 'high', 'low', 'volume']
    REQUIRED_INDEX_COLUMNS = ['open', 'close', 'high', 'low']
    
    # 缓存目录
    CACHE_DIR = Path('data_cache')

    def __init__(self, max_retries=3, retry_delay=1, use_cache=True):
        """
        初始化A股数据下载器
        
        Args:
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
            use_cache: 是否使用缓存
        """
        super().__init__(max_retries, retry_delay)
        self.use_cache = use_cache
        
        # 创建缓存目录
        if self.use_cache:
            os.makedirs(self.CACHE_DIR, exist_ok=True)
    
    def format_date_for_query(self, date_str):
        """
        格式化日期字符串用于查询
        
        Args:
            date_str: 日期字符串
        
        Returns:
            str: 格式化后的日期字符串
        """
        return datetime.strptime(date_str, '%Y-%m-%d').strftime('%Y%m%d')

    def process_date_params(self, start_date, end_date):
        """
        处理日期参数
        
        Args:
            start_date: 起始日期
            end_date: 结束日期
        
        Returns:
            tuple: 处理后的起始日期和结束日期
        """
        if start_date is None:
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        return start_date, end_date
    
    def get_market_prefix(self, code):
        """
        根据股票代码获取市场前缀
        
        Args:
            code: 股票代码
        
        Returns:
            str: 市场前缀 (sh/sz/bj)
        """
        if code.startswith('6'):
            return 'sh'
        elif code.startswith(('0', '3')):
            return 'sz'
        elif code.startswith('8'):
            return 'bj'
        elif code == '000001' and len(code) == 6:  # 上证指数
            return 'sh'
        else:
            return 'bj'  # 默认返回北交所
    
    def standardize_dataframe(self, df, code, is_index=False):
        """
        标准化DataFrame格式
        
        Args:
            df: 原始DataFrame
            code: 股票/指数代码
            is_index: 是否为指数数据
            
        Returns:
            DataFrame: 标准化后的DataFrame
        """
        if df.empty:
            return df
            
        # 处理日期列
        if 'date' not in df.columns and df.index.name != 'date':
            if '日期' in df.columns:
                df['date'] = pd.to_datetime(df['日期'])
                df = df.drop(columns=['日期'])
            elif isinstance(df.index[0], (datetime, pd.Timestamp)) or pd.api.types.is_datetime64_any_dtype(df.index):
                df['date'] = df.index
            else:
                df['date'] = pd.to_datetime(df.index)
        elif 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            
        # 重命名列
        rename_dict = {k: v for k, v in self.COLUMN_MAPPINGS.items() if k in df.columns}
        df = df.rename(columns=rename_dict)
        
        # 检查必要列
        required_columns = self.REQUIRED_INDEX_COLUMNS if is_index else self.REQUIRED_STOCK_COLUMNS
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            self.logger.error(f"数据缺少必要的列: {missing_columns}")
            return pd.DataFrame()
            
        # 添加可选列
        optional_columns = ['volume', 'amount', 'change_pct', 'change', 'turnover', 
                           'transactions', 'amplitude', 'total_market_value', 
                           'circulating_market_value']
        for col in optional_columns:
            if col not in df.columns:
                df[col] = None if col != 'volume' and col != 'amount' else 0
                
        # 添加代码列
        df['code'] = code
        
        # 设置日期为索引
        if 'date' in df.columns:
            df = df.set_index('date')
            
        return df
    
    def validate_data(self, df, is_index=False):
        """
        验证数据质量
        
        Args:
            df: 待验证的DataFrame
            is_index: 是否为指数数据
            
        Returns:
            bool: 数据是否有效
        """
        if df.empty:
            return False
            
        # 检查价格的基本合理性
        price_cols = ['open', 'close', 'high', 'low']
        for col in price_cols:
            if col in df.columns:
                # 检查是否有负值
                if (df[col] < 0).any():
                    self.logger.warning(f"数据中存在负的{col}值")
                    return False
                    
                # 检查是否有异常值(超出合理范围)
                if not is_index and ((df[col] > 10000) | (df[col] < 0.1)).any():
                    self.logger.warning(f"数据中存在异常{col}值")
                    return False
        
        # 检查交易量
        if 'volume' in df.columns and (df['volume'] < 0).any():
            self.logger.warning("数据中存在负的成交量")
            return False
            
        # 检查日期连续性 (允许节假日等原因缺失)
        dates = df.index
        if len(dates) > 1:
            if (dates.max() - dates.min()).days > len(dates) * 3:  # 允许最多2/3的日期缺失
                self.logger.warning("数据日期不连续")
                return False
        
        return True
    
    def get_cache_path(self, data_type, code, start_date, end_date, **kwargs):
        """
        获取缓存文件路径
        
        Args:
            data_type: 数据类型，如'stock'或'index'
            code: 股票/指数代码
            start_date: 开始日期
            end_date: 结束日期
            **kwargs: 其他参数
            
        Returns:
            Path: 缓存文件路径
        """
        # 创建参数字符串
        params_str = f"{data_type}_{code}_{start_date}_{end_date}"
        for k, v in kwargs.items():
            params_str += f"_{k}_{v}"
            
        # 计算哈希值作为文件名
        hash_name = hashlib.md5(params_str.encode()).hexdigest()
        return self.CACHE_DIR / f"{hash_name}.pkl"
    
    def load_from_cache(self, cache_path):
        """
        从缓存加载数据
        
        Args:
            cache_path: 缓存文件路径
            
        Returns:
            DataFrame or None: 缓存的数据，如果不存在则返回None
        """
        if not self.use_cache or not cache_path.exists():
            return None
            
        try:
            # 检查缓存是否过期 (1天)
            if datetime.fromtimestamp(cache_path.stat().st_mtime) < datetime.now() - timedelta(days=1):
                return None
                
            with open(cache_path, 'rb') as f:
                df = pickle.load(f)
                self.logger.info(f"从缓存加载数据: {cache_path}")
                return df
        except Exception as e:
            self.logger.warning(f"加载缓存失败: {e}")
            return None
    
    def save_to_cache(self, df, cache_path):
        """
        保存数据到缓存
        
        Args:
            df: 数据DataFrame
            cache_path: 缓存文件路径
        """
        if not self.use_cache or df.empty:
            return
            
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(df, f)
                self.logger.info(f"数据已保存到缓存: {cache_path}")
        except Exception as e:
            self.logger.warning(f"保存缓存失败: {e}")
    
    def get_stock_list(self):
        """
        获取A股股票列表
        
        Returns:
            DataFrame: A股股票列表，包含代码、名称、市场、行业等信息
        """
        # 检查是否存在缓存
        cache_path = self.CACHE_DIR / "stock_list.pkl"
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        try:
            # 获取A股股票列表
            try:
                stock_info = ak.stock_info_a_code_name()
                self.logger.info(f"原始股票列表数据列: {stock_info.columns.tolist()}")
                
                # 创建全新的DataFrame，只保留必要的列
                stock_list = pd.DataFrame()
                if 'code' in stock_info.columns:
                    stock_list['code'] = stock_info['code']
                elif '代码' in stock_info.columns:
                    stock_list['code'] = stock_info['代码']
                else:
                    # 尝试查找包含"code"或"代码"的列
                    code_col = next((col for col in stock_info.columns if 'code' in col.lower() or '代码' in col.lower()), None)
                    if code_col:
                        stock_list['code'] = stock_info[code_col]
                    else:
                        raise ValueError("无法找到股票代码列")
                
                # 添加股票名称
                if 'name' in stock_info.columns:
                    stock_list['name'] = stock_info['name']
                elif '名称' in stock_info.columns:
                    stock_list['name'] = stock_info['名称']
                else:
                    name_col = next((col for col in stock_info.columns if 'name' in col.lower() or '名称' in col.lower()), None)
                    if name_col:
                        stock_list['name'] = stock_info[name_col]
                    else:
                        stock_list['name'] = "未知"
                
                # 添加市场信息
                stock_list['market'] = stock_list['code'].apply(self.get_market_prefix)
                
                # 添加行业信息占位符
                stock_list['industry'] = None
                
                # 尝试获取行业信息
                self._add_industry_info(stock_list)
                
                self.logger.info(f"成功获取A股股票列表，共{len(stock_list)}只股票")
                
                # 保存到缓存
                self.save_to_cache(stock_list, cache_path)
                
                return stock_list
                
            except Exception as e:
                self.logger.error(f"获取A股股票列表时发生错误: {str(e)}")
                # 尝试其他获取股票列表的方法
                return self._get_stock_list_fallback()
                
        except Exception as e:
            self.logger.error(f"获取A股股票列表失败: {e}")
            return pd.DataFrame(columns=['code', 'name', 'market', 'industry'])

    def _add_industry_info(self, stock_list):
        """
        添加行业信息到股票列表
        
        Args:
            stock_list: 股票列表DataFrame
        """
        try:
            industry_apis = [
                self._get_industry_info_method1,
                self._get_industry_info_method2
            ]
            
            for api_func in industry_apis:
                try:
                    industry_info = api_func()
                    self.logger.info(f"行业信息数据列: {industry_info.columns.tolist()}")
                    
                    if industry_info.empty:
                        continue
                        
                    # 查找代码列和行业列
                    code_cols = [col for col in industry_info.columns 
                               if '代码' in col or 'code' in col.lower()]
                    industry_cols = [col for col in industry_info.columns 
                                   if '板块' in col or '行业' in col or 'industry' in col.lower()]
                    
                    if not code_cols or not industry_cols:
                        continue
                        
                    code_col = code_cols[0]
                    industry_col = industry_cols[0]
                    
                    # 确保股票代码格式一致
                    industry_info_clean = industry_info.copy()
                    industry_info_clean[code_col] = industry_info_clean[code_col].astype(str).apply(
                        lambda x: x.replace('sh', '').replace('sz', '').replace('bj', '')
                    )
                    
                    # 使用字典映射更新行业信息
                    industry_dict = dict(zip(industry_info_clean[code_col], industry_info_clean[industry_col]))
                    stock_list['industry'] = stock_list['code'].map(industry_dict)
                    
                    self.logger.info(f"已添加行业信息，共{stock_list['industry'].count()}只股票有行业信息")
                    return
                    
                except Exception as e:
                    self.logger.warning(f"添加行业信息失败: {e}")
                    continue
        
        except Exception as e:
            self.logger.error(f"处理行业信息时出错: {e}")

    def _get_stock_list_fallback(self):
        """备用方法获取股票列表"""
        try:
            # 尝试不同的接口
            try:
                # 方法1: 使用stock_zh_a_spot_em
                df = ak.stock_zh_a_spot_em()
                
                stock_list = pd.DataFrame()
                stock_list['code'] = df['代码'].astype(str)
                stock_list['name'] = df['名称']
                stock_list['market'] = stock_list['code'].apply(self.get_market_prefix)
                stock_list['industry'] = None
                
                self.logger.info(f"通过备用方法获取A股股票列表，共{len(stock_list)}只股票")
                return stock_list
                
            except Exception as e1:
                self.logger.warning(f"备用方法1获取股票列表失败: {e1}")
                
                # 方法2: 使用stock_sh_a_spot_em和stock_sz_a_spot_em
                try:
                    df_sh = ak.stock_sh_a_spot_em()
                    df_sz = ak.stock_sz_a_spot_em()
                    df = pd.concat([df_sh, df_sz])
                    
                    stock_list = pd.DataFrame()
                    stock_list['code'] = df['代码'].astype(str)
                    stock_list['name'] = df['名称']
                    stock_list['market'] = stock_list['code'].apply(self.get_market_prefix)
                    stock_list['industry'] = None
                    
                    self.logger.info(f"通过备用方法2获取A股股票列表，共{len(stock_list)}只股票")
                    return stock_list
                    
                except Exception as e2:
                    self.logger.warning(f"备用方法2获取股票列表失败: {e2}")
                    
                    # 返回空DataFrame
                    return pd.DataFrame(columns=['code', 'name', 'market', 'industry'])
                
        except Exception as e:
            self.logger.error(f"所有备用方法获取股票列表失败: {e}")
            return pd.DataFrame(columns=['code', 'name', 'market', 'industry'])
    
    def _get_industry_info_method1(self):
        """获取行业信息的方法1"""
        return ak.stock_board_industry_name_em()
    
    def _get_industry_info_method2(self):
        """获取行业信息的方法2"""
        return ak.stock_board_industry_cons_em()
    
    def download_stock_data(self, code, start_date=None, end_date=None, adjust="qfq"):
        """
        下载A股股票历史数据
        
        Args:
            code: 股票代码
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            adjust: 复权类型，'qfq'表示前复权，'hfq'表示后复权，None表示不复权
            
        Returns:
            DataFrame: 历史数据
        """
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 检查缓存
        cache_path = self.get_cache_path("stock", code, start_date, end_date, adjust=adjust)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        # 格式化日期为akshare查询格式
        start_date_fmt = self.format_date_for_query(start_date)
        end_date_fmt = self.format_date_for_query(end_date)
        
        # 获取市场前缀
        market = self.get_market_prefix(code)
        
        # 完整股票代码
        full_code = f"{market}{code}"
        
        # 定义数据获取方法
        data_methods = [
            # 方法1: 使用stock_zh_a_hist接口
            lambda: ak.stock_zh_a_hist(symbol=code, period="daily", 
                                     start_date=start_date, end_date=end_date, 
                                     adjust=adjust if adjust else ""),
            # 方法2: 使用stock_zh_a_daily接口
            lambda: ak.stock_zh_a_daily(symbol=full_code, 
                                      start_date=start_date_fmt, end_date=end_date_fmt, 
                                      adjust=adjust)
        ]
        
        # 尝试不同的方法获取数据
        for retry in range(self.max_retries):
            for method_idx, method in enumerate(data_methods):
                try:
                    self.logger.info(f"正在下载A股股票 {code} 的历史数据，使用方法{method_idx+1}，日期范围: {start_date}至{end_date}")
                    df = method()
                    
                    # 标准化数据
                    df = self.standardize_dataframe(df, code)
                    
                    # 验证数据
                    if not df.empty and self.validate_data(df):
                        # 保存到缓存
                        self.save_to_cache(df, cache_path)
                        
                        self.logger.info(f"成功下载股票 {code} 的历史数据，共{len(df)}条记录")
                        return df
                    else:
                        self.logger.warning(f"方法{method_idx+1}下载的数据无效，尝试下一种方法")
                        
                except Exception as e:
                    self.logger.warning(f"方法{method_idx+1}下载股票 {code} 数据失败: {e}")
            
            # 所有方法都失败，等待后重试
            if retry < self.max_retries - 1:
                time.sleep(self.retry_delay)
                self.logger.info(f"重试下载股票 {code} 数据 (尝试 {retry+2}/{self.max_retries})")
        
        self.logger.error(f"下载股票 {code} 的历史数据失败，已达到最大重试次数")
        return pd.DataFrame()  # 返回空DataFrame表示无数据
    
    def download_index_data(self, code, start_date=None, end_date=None):
        """
        下载A股指数历史数据
        
        Args:
            code: 指数代码，如'000001'表示上证指数
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            DataFrame: 历史数据
        """
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 检查缓存
        cache_path = self.get_cache_path("index", code, start_date, end_date)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        # 格式化日期为akshare查询格式
        start_date_fmt = self.format_date_for_query(start_date)
        end_date_fmt = self.format_date_for_query(end_date)
        
        # 获取市场前缀
        market = self.get_market_prefix(code)
        
        # 完整指数代码
        full_code = f"{market}{code}"
        
        # 定义数据获取方法
        data_methods = [
            # 方法1: 使用stock_zh_index_daily接口
            lambda: ak.stock_zh_index_daily(symbol=full_code),
            # 方法2: 使用stock_zh_index_daily_tx接口
            lambda: ak.stock_zh_index_daily_tx(symbol=full_code),
            # 方法3: 使用stock_zh_index_daily_em接口
            lambda: ak.stock_zh_index_daily_em(symbol=code)
        ]
        
        # 尝试不同的方法获取数据
        for retry in range(self.max_retries):
            for method_idx, method in enumerate(data_methods):
                try:
                    self.logger.info(f"正在下载A股指数 {code} 的历史数据，使用方法{method_idx+1}，日期范围: {start_date}至{end_date}")
                    df = method()
                    
                    # 标准化数据
                    df = self.standardize_dataframe(df, code, is_index=True)
                    
                    # 筛选日期范围
                    if not df.empty:
                        df = df[(df.index >= pd.to_datetime(start_date)) & 
                               (df.index <= pd.to_datetime(end_date))]
                    
                    # 验证数据
                    if not df.empty and self.validate_data(df, is_index=True):
                        # 保存到缓存
                        self.save_to_cache(df, cache_path)
                        
                        self.logger.info(f"成功下载指数 {code} 的历史数据，共{len(df)}条记录")
                        return df
                    else:
                        self.logger.warning(f"方法{method_idx+1}下载的数据无效，尝试下一种方法")
                        
                except Exception as e:
                    self.logger.warning(f"方法{method_idx+1}下载指数 {code} 数据失败: {e}")
            
            # 所有方法都失败，等待后重试
            if retry < self.max_retries - 1:
                time.sleep(self.retry_delay)
                self.logger.info(f"重试下载指数 {code} 数据 (尝试 {retry+2}/{self.max_retries})")
        
        self.logger.error(f"下载指数 {code} 的历史数据失败，已达到最大重试次数")
        return pd.DataFrame()