#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
港股数据下载器模块

负责从港股市场下载股票数据，使用akshare库实现。
"""

from .hk_stock_downloader import HKStockDownloader

__all__ = ['HKStockDownloader']