#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
港股数据下载器

负责从港股市场下载股票数据，使用akshare库实现。
"""

import os
import time
import pandas as pd
import akshare as ak
from datetime import datetime, timedelta
import numpy as np
import hashlib

# 导入基类
from ..base_downloader import BaseDownloader


class HKStockDownloader(BaseDownloader):
    """
    港股数据下载器
    
    负责从港股市场下载股票数据，使用akshare库实现。
    """

    def format_date_for_query(self, date_str):
        """
        格式化日期字符串用于查询
        
        Args:
            date_str: 日期字符串
        
        Returns:
            str: 格式化后的日期字符串
        """
        return datetime.strptime(date_str, '%Y-%m-%d').strftime('%Y%m%d')

    def process_date_params(self, start_date, end_date):
        """
        处理日期参数
        
        Args:
            start_date: 起始日期
            end_date: 结束日期
        
        Returns:
            tuple: 处理后的起始日期和结束日期
        """
        if start_date is None:
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        if end_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
        return start_date, end_date
    
    def __init__(self, max_retries=3, retry_delay=1):
        """
        初始化港股数据下载器
        
        Args:
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
        """
        super().__init__(max_retries, retry_delay)
    
    def get_stock_list(self):
        """
        获取港股股票列表
        
        Returns:
            DataFrame: 港股股票列表，包含代码、名称、市场、行业等信息
        """
        try:
            # 获取港股股票列表
            stock_list = ak.stock_hk_spot_em()
            
            # 重命名列
            stock_list = stock_list.rename(columns={
                '代码': 'code',
                '名称': 'name',
                '板块': 'industry'
            })
            
            # 添加市场信息
            stock_list['market'] = 'hk'
            
            self.logger.info(f"成功获取港股股票列表，共{len(stock_list)}只股票")
            return stock_list
            
        except Exception as e:
            self.logger.error(f"获取港股股票列表失败: {e}")
            return pd.DataFrame()
    
    def download_stock_data(self, code, start_date=None, end_date=None, adjust="qfq"):
        """下载港股股票历史数据"""
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 处理股票代码格式
        # 确保港股代码格式一致（5位数字，前导0）
        if code.isdigit():
            code = code.zfill(5)
        
        # 检查缓存
        cache_path = self.get_cache_path("stock", code, start_date, end_date, adjust)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        self.logger.info(f"正在下载港股 {code} 的历史数据，日期范围: {start_date}至{end_date}")
        
        # 尝试多种方法获取数据
        for retry in range(self.max_retries):
            # 方法1: 使用akshare的新API
            try:
                import akshare as ak
                
                # 特殊处理商汤科技
                if code == "00020" or code == "20":
                    code = "00020"  # 确保代码格式正确
                    self.logger.info(f"特殊处理商汤科技股票数据")
                    
                    # 尝试使用不同的API终端点获取数据
                    try:
                        # 尝试使用股票日线行情数据接口
                        df = ak.stock_hk_daily(symbol=code, adjust=adjust)
                    except:
                        # 备用方法
                        df = ak.stock_hk_spot_em()
                        if not df.empty:
                            # 筛选商汤科技的数据
                            df = df[df['代码'] == code]
                            # 获取更多历史数据
                            symbol_name = df.iloc[0]['名称'] if not df.empty else "商汤-W"
                            df = ak.stock_hk_hist(symbol=symbol_name, period="daily", 
                                               start_date=start_date.replace('-', ''), 
                                               end_date=end_date.replace('-', ''), adjust=adjust)
                else:
                    # 常规港股下载
                    df = ak.stock_hk_daily(symbol=code, adjust=adjust)
                
                if not df.empty:
                    # 标准化数据格式
                    df = self.standardize_dataframe(df, code)
                    
                    # 筛选日期范围
                    if isinstance(df.index, pd.DatetimeIndex):
                        df = df[(df.index >= pd.to_datetime(start_date)) & 
                               (df.index <= pd.to_datetime(end_date))]
                    
                    # 验证和保存
                    if not df.empty:
                        self.save_to_cache(df, cache_path)
                        self.logger.info(f"成功下载港股 {code} 数据，共{len(df)}条记录")
                        return df
                        
            except Exception as e:
                self.logger.warning(f"方法1下载港股 {code} 数据失败: {e}")
            
            # 方法2: 使用另一个akshare API
            try:
                df = ak.stock_hk_hist(symbol=code, period="daily", 
                                   start_date=start_date.replace('-', ''), 
                                   end_date=end_date.replace('-', ''), adjust=adjust)
                
                if not df.empty:
                    # 标准化列名
                    df = self.standardize_dataframe(df, code)
                    
                    # 筛选日期范围
                    if isinstance(df.index, pd.DatetimeIndex):
                        df = df[(df.index >= pd.to_datetime(start_date)) & 
                               (df.index <= pd.to_datetime(end_date))]
                    
                    # 验证和保存
                    if not df.empty:
                        self.save_to_cache(df, cache_path)
                        self.logger.info(f"成功使用方法2下载港股 {code} 数据，共{len(df)}条记录")
                        return df
                
            except Exception as e:
                self.logger.warning(f"方法2下载港股 {code} 数据失败: {e}")
            
            # 休息后重试
            if retry < self.max_retries - 1:
                time.sleep(self.retry_delay)
        
        # 所有方法失败
        self.logger.error(f"下载港股 {code} 数据失败，已尝试所有可用方法")
        return pd.DataFrame()  # 返回空DataFrame
    
    def download_index_data(self, code, start_date=None, end_date=None):
        """
        下载港股指数历史数据
        
        Args:
            code: 指数代码，如'HSI'表示恒生指数
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            DataFrame: 历史数据
        """
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 检查缓存
        cache_path = self.get_cache_path("index", code, start_date, end_date)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        self.logger.info(f"正在下载港股指数 {code} 的历史数据，日期范围: {start_date}至{end_date}")
        
        # 尝试使用 akshare 获取数据
        for retry in range(self.max_retries):
            try:
                import akshare as ak
                
                # 根据指数代码使用对应的方法
                if code == "HSI":  # 恒生指数
                    df = ak.stock_hk_index_daily_em(symbol="恒生指数")
                else:
                    try:
                        df = ak.stock_hk_index_daily_em(symbol=code)
                    except:
                        self.logger.warning(f"无法直接获取指数 {code}，尝试其他方法")
                        return pd.DataFrame()
                
                # 标准化列名
                if not df.empty:
                    df = self.standardize_dataframe(df, code, is_index=True)
                    
                    # 筛选日期范围
                    df = df[(df.index >= pd.to_datetime(start_date)) & 
                           (df.index <= pd.to_datetime(end_date))]
                
                # 检查数据有效性
                if df.empty:
                    self.logger.warning(f"获取的指数数据为空，尝试第{retry+1}次")
                    if retry < self.max_retries - 1:
                        time.sleep(self.retry_delay)
                    continue
                
                # 保存到缓存
                self.save_to_cache(df, cache_path)
                
                self.logger.info(f"成功下载指数 {code} 的历史数据，共{len(df)}条记录")
                return df
                
            except Exception as e:
                self.logger.error(f"下载指数 {code} 的历史数据失败 (尝试 {retry+1}/{self.max_retries}): {e}")
                if retry < self.max_retries - 1:
                    time.sleep(self.retry_delay)
        
        # 如果尝试了所有方法仍然失败
        self.logger.error(f"下载指数 {code} 的历史数据失败，已达到最大重试次数")
        return pd.DataFrame()  # 返回空DataFrame
    
    def _process_index_data(self, df, code, start_date, end_date):
        """处理指数数据，统一格式"""
        # 检查并重命名日期列
        if 'date' in df.columns:
            date_col = 'date'
        elif '日期' in df.columns:
            date_col = '日期'
        else:
            # 查找可能的日期列
            date_candidates = [col for col in df.columns if '日' in col or 'date' in col.lower()]
            date_col = date_candidates[0] if date_candidates else df.columns[0]
        
        # 转换日期并筛选
        df['date'] = pd.to_datetime(df[date_col])
        df = df[(df['date'] >= pd.to_datetime(start_date)) & (df['date'] <= pd.to_datetime(end_date))]
        
        # 检查数据是否为空
        if df.empty:
            self.logger.warning(f"指数 {code} 在指定日期范围内没有数据")
            return pd.DataFrame()
        
        # 重命名列（根据实际列名灵活处理）
        col_mapping = {
            '开盘': 'open', '开盘价': 'open', 'Open': 'open',
            '收盘': 'close', '收盘价': 'close', 'Close': 'close',
            '最高': 'high', '最高价': 'high', 'High': 'high',
            '最低': 'low', '最低价': 'low', 'Low': 'low',
            '成交量': 'volume', 'Volume': 'volume',
            '成交额': 'amount', '成交额(元)': 'amount'
        }
        
        # 只重命名存在的列
        rename_dict = {k: v for k, v in col_mapping.items() if k in df.columns}
        df = df.rename(columns=rename_dict)
        
        # 添加缺失的列
        required_columns = ['open', 'close', 'high', 'low']
        for col in required_columns:
            if col not in df.columns:
                self.logger.warning(f"数据中缺少{col}列，使用NaN填充")
                df[col] = None
        
        if 'volume' not in df.columns:
            df['volume'] = 0
        if 'amount' not in df.columns:
            df['amount'] = 0
        
        # 添加指数代码列
        df['code'] = code
        
        # 设置日期为索引
        df = df.set_index('date')
        
        self.logger.info(f"成功下载指数 {code} 的历史数据，共{len(df)}条记录")
        return df
    
    def _generate_mock_index_data(self, code, start_date, end_date):
        """生成模拟指数数据"""
        self.logger.info(f"生成模拟指数 {code} 数据，日期范围: {start_date}至{end_date}")
        
        # 计算日期范围
        start = pd.to_datetime(start_date)
        end = pd.to_datetime(end_date)
        dates = pd.date_range(start=start, end=end, freq='B')  # 工作日
        
        # 根据不同指数设置初始价格
        if code == 'HSI':
            base_price = 20000  # 恒生指数
        elif code == 'HSCEI':
            base_price = 7000   # 国企指数
        elif code == 'HSTECH':
            base_price = 4500   # 恒生科技指数
        else:
            base_price = 10000  # 默认基准价格
        
        # 生成随机价格数据
        np.random.seed(42)  # 使用固定种子确保可重复性
        price_changes = np.random.normal(0, 1, len(dates)) * base_price * 0.015  # 每日变动±1.5%
        
        # 累积价格变化
        prices = np.cumprod(1 + price_changes / base_price) * base_price
        
        # 创建数据框
        data = {
            'date': dates,
            'open': prices * (1 + np.random.normal(0, 0.005, len(dates))),
            'close': prices,
            'high': prices * (1 + np.abs(np.random.normal(0, 0.01, len(dates)))),
            'low': prices * (1 - np.abs(np.random.normal(0, 0.01, len(dates)))),
            'volume': np.random.randint(100000, 1000000, size=len(dates)),
            'amount': prices * np.random.randint(100000, 1000000, size=len(dates)),
            'code': code
        }
        
        df = pd.DataFrame(data)
        df['date'] = pd.to_datetime(df['date'])
        df = df.set_index('date')
        
        self.logger.info(f"成功生成模拟指数 {code} 的历史数据，共{len(df)}条记录")
        return df
    
    def get_index_stocks(self, index_code):
        """
        获取指数成分股
        
        Args:
            index_code: 指数代码，如'HSI'表示恒生指数
            
        Returns:
            list: 成分股代码列表
        """
        try:
            self.logger.info(f"正在获取指数 {index_code} 的成分股")
            
            # 方法1: 尝试使用stock_hk_index_spot_em获取主要成分股
            try:
                df = ak.stock_hk_index_spot_em()
                if not df.empty:
                    self.logger.info(f"获取到指数概览数据: {df.columns.tolist()}")
            except Exception as e:
                self.logger.warning(f"无法获取指数概览: {e}")
            
            # 方法2: 直接提供主要成分股的静态列表
            if index_code == 'HSI':  # 恒生指数
                # 主要恒生指数成分股
                stock_codes = [
                    "00001", "00002", "00003", "00005", "00388", 
                    "00700", "00941", "01299", "01398", "02318", 
                    "02319", "00027", "00066", "00823", "00939", 
                    "01038", "01044", "01093", "01177", "01211", 
                    "01876", "01997", "02020", "02269", "02382", 
                    "02688", "03690", "03988", "09988", "09999"
                ]
                self.logger.info(f"使用静态成分股列表，恒生指数主要成分股，共{len(stock_codes)}只")
                return stock_codes
            
            elif index_code == 'HSCEI':  # 恒生中国企业指数
                # 主要国企指数成分股
                stock_codes = [
                    "00941", "01398", "00939", "02318", "03988",
                    "00386", "00857", "02628", "03968", "00883",
                    "02601", "01088", "00728", "02328", "00688",
                    "06185", "00902", "01109", "01919", "06030"
                ]
                self.logger.info(f"使用静态成分股列表，国企指数主要成分股，共{len(stock_codes)}只")
                return stock_codes
            
            elif index_code == 'HSTECH':  # 恒生科技指数
                # 恒生科技指数成分股
                stock_codes = [
                    "00700", "09988", "09999", "03690", "01024",
                    "00909", "09618", "01810", "02015", "00981",
                    "06969", "09888", "01833", "02382", "00772",
                    "09626", "09961", "09992", "06618", "09984"
                ]
                self.logger.info(f"使用静态成分股列表，恒生科技指数主要成分股，共{len(stock_codes)}只")
                return stock_codes
            
            self.logger.warning(f"不支持的指数代码: {index_code}，返回空成分股列表")
            return []
                
        except Exception as e:
            self.logger.error(f"获取指数 {index_code} 的成分股失败: {e}")
            return []

    def _generate_mock_stock_data(self, code, start_date, end_date):
        """
        生成模拟港股数据，用于在无法获取真实数据时提供测试数据
        
        Args:
            code: 股票代码
            start_date: 起始日期
            end_date: 结束日期
            
        Returns:
            DataFrame: 模拟的股票数据
        """
        self.logger.info(f"生成模拟港股数据: {code}, 日期范围: {start_date} 至 {end_date}")
        
        # 转换日期为datetime对象
        start_date = pd.to_datetime(start_date)
        end_date = pd.to_datetime(end_date)
        
        # 生成日期范围
        date_range = pd.date_range(start=start_date, end=end_date, freq='B')
        
        # 使用股票代码作为随机种子，确保相同股票生成相同数据
        np.random.seed(int(hashlib.md5(code.encode()).hexdigest(), 16) % 10000)
        
        # 设置基础价格 - 使用港股常见价格范围
        base_price = 0
        if code == '00700':  # 腾讯控股
            base_price = 350.0
        elif code == '09988':  # 阿里巴巴
            base_price = 80.0
        elif code == '02498':  # 速腾聚创
            base_price = 65.0
        elif code == '03690':  # 美团
            base_price = 120.0
        elif code == '00941':  # 中国移动
            base_price = 80.0
        else:
            # 为其他代码生成一个随机的基础价格
            base_price = np.random.uniform(10.0, 200.0)
        
        # 生成价格序列
        n = len(date_range)
        prices = np.zeros(n)
        prices[0] = base_price
        
        # 生成随机价格变动
        for i in range(1, n):
            change_pct = np.random.normal(0, 0.02)  # 每日价格变动率
            prices[i] = prices[i-1] * (1 + change_pct)
        
        # 创建DataFrame
        df = pd.DataFrame({
            'code': code,
            'date': date_range,
            'open': prices * (1 + np.random.normal(0, 0.005, n)),
            'high': prices * (1 + np.random.uniform(0.001, 0.02, n)),
            'low': prices * (1 - np.random.uniform(0.001, 0.02, n)),
            'close': prices,
            'volume': np.random.randint(1000000, 20000000, n),
            'amount': np.random.randint(10000000, 1000000000, n)
        })
        
        # 设置日期为索引
        df.set_index('date', inplace=True)
        
        self.logger.info(f"成功生成模拟港股 {code} 的历史数据，共{len(df)}条记录")
        return df

    def get_cache_path(self, data_type, code, start_date, end_date, adjust=None):
        """
        获取缓存文件路径
        
        Args:
            data_type: 数据类型，'stock'或'index'
            code: 股票或指数代码
            start_date: 起始日期
            end_date: 结束日期
            adjust: 复权类型
            
        Returns:
            Path: 缓存文件路径
        """
        # 生成缓存文件名
        cache_key = f"{data_type}_{code}_{start_date}_{end_date}_{adjust}"
        cache_file = hashlib.md5(cache_key.encode()).hexdigest() + ".pkl"
        
        return self.CACHE_DIR / cache_file