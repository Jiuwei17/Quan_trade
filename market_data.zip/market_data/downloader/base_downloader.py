import os
import logging
from abc import ABC, abstractmethod
from datetime import datetime, timedelta
import pandas as pd

class BaseDownloader(ABC):
    """
    下载器基类
    """

    def __init__(self, max_retries=3, retry_delay=1):
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.logger = logging.getLogger(self.__class__.__name__)

    @abstractmethod
    def get_stock_list(self):
        """
        获取股票列表
        """
        pass

    @abstractmethod
    def download_stock_data(self, code, start_date, end_date):
        """
        下载股票数据
        """
        pass

    @abstractmethod
    def download_index_data(self, code, start_date, end_date):
        """
        下载指数数据
        """
        pass

    def get_data_dir(self):
        """
        获取数据存储目录
        """
        data_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'data')
        os.makedirs(data_dir, exist_ok=True)
        return data_dir

    def get_log_dir(self):
        """
        获取日志存储目录
        """
        log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'logs')
        os.makedirs(log_dir, exist_ok=True)
        return log_dir

    def download_stock_data_incremental(self, code, db_manager, start_date=None, end_date=None, adjust=None, days=30):
        """
        增量下载股票数据
        
        Args:
            code: 股票代码
            db_manager: 数据库管理器实例
            start_date: 起始日期，如果为None，则自动确定
            end_date: 结束日期，如果为None，则使用当前日期
            adjust: 复权类型
            days: 如果没有历史数据，下载最近days天的数据
            
        Returns:
            DataFrame: 下载的股票数据
        """
        # 如果没有指定日期范围，则确定合适的日期范围
        if start_date is None or end_date is None:
            # 获取数据库中该股票的最新日期
            latest_date = db_manager.get_latest_trading_date(code)
            
            # 设置结束日期为当前日期
            if end_date is None:
                end_date = datetime.now().strftime('%Y-%m-%d')
            
            # 如果数据库中没有该股票数据，则下载最近days天的数据
            if latest_date is None:
                if start_date is None:
                    start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
                self.logger.info(f"股票 {code} 没有历史数据，将下载 {start_date} 至 {end_date} 的数据")
            else:
                # 有数据，则从最新日期后一天开始下载
                if start_date is None:
                    latest_date_obj = datetime.strptime(latest_date, '%Y-%m-%d')
                    start_date = (latest_date_obj + timedelta(days=1)).strftime('%Y-%m-%d')
                
                # 如果最新日期是今天或未来日期，无需更新
                if start_date > end_date:
                    self.logger.info(f"股票 {code} 数据已是最新，无需更新")
                    return pd.DataFrame()  # 返回空DataFrame
        
        # 下载数据
        self.logger.info(f"下载股票 {code} 数据，日期范围: {start_date} 至 {end_date}")
        data = self.download_stock_data(code, start_date, end_date, adjust)
        
        # 返回下载的数据
        return data