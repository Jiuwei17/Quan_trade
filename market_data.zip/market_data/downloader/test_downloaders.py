#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
股票下载器功能验证脚本

用于验证A股、港股和美股三个市场的股票下载器功能。
"""

import os
import sys
import pandas as pd
from datetime import datetime, timedelta
import logging

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('downloader_test')

# 添加项目根目录到系统路径
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, root_dir)

# 导入下载器
from market_data.downloader.a_stock import AStockDownloader
from market_data.downloader.hk_stock import HKStockDownloader
from market_data.downloader.us_stock import USStockDownloader


def test_a_stock_downloader():
    """
    测试A股下载器功能
    """
    logger.info("===== 开始测试A股下载器 =====")
    
    # 创建下载器实例
    downloader = AStockDownloader()
    
    # 测试获取股票列表
    logger.info("1. 测试获取A股股票列表")
    stock_list = downloader.get_stock_list()
    if not stock_list.empty:
        logger.info(f"成功获取A股股票列表，共{len(stock_list)}只股票")
        logger.info(f"股票列表前5条记录:\n{stock_list.head()}")
    else:
        logger.error("获取A股股票列表失败")
    
    # 测试下载单只股票数据
    logger.info("\n2. 测试下载单只A股股票数据")
    code = '600519'  # 贵州茅台
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    if not stock_data.empty:
        logger.info(f"成功下载股票{code}的历史数据，共{len(stock_data)}条记录")
        logger.info(f"股票数据前5条记录:\n{stock_data.head()}")
    else:
        logger.error(f"下载股票{code}的历史数据失败")
    
    # 测试下载指数数据
    logger.info("\n3. 测试下载A股指数数据")
    index_code = '000001'  # 上证指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    if not index_data.empty:
        logger.info(f"成功下载指数{index_code}的历史数据，共{len(index_data)}条记录")
        logger.info(f"指数数据前5条记录:\n{index_data.head()}")
    else:
        logger.error(f"下载指数{index_code}的历史数据失败")
    
    logger.info("===== A股下载器测试完成 =====\n")


def test_hk_stock_downloader():
    """
    测试港股下载器功能
    """
    logger.info("===== 开始测试港股下载器 =====")
    
    # 创建下载器实例
    downloader = HKStockDownloader()
    
    # 测试获取股票列表
    logger.info("1. 测试获取港股股票列表")
    stock_list = downloader.get_stock_list()
    if not stock_list.empty:
        logger.info(f"成功获取港股股票列表，共{len(stock_list)}只股票")
        logger.info(f"股票列表前5条记录:\n{stock_list.head()}")
    else:
        logger.error("获取港股股票列表失败")
    
    # 测试下载单只股票数据
    logger.info("\n2. 测试下载单只港股股票数据")
    code = '00700'  # 腾讯控股
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    if not stock_data.empty:
        logger.info(f"成功下载股票{code}的历史数据，共{len(stock_data)}条记录")
        logger.info(f"股票数据前5条记录:\n{stock_data.head()}")
    else:
        logger.error(f"下载股票{code}的历史数据失败")
    
    # 测试下载指数数据
    logger.info("\n3. 测试下载港股指数数据")
    index_code = 'HSI'  # 恒生指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    if not index_data.empty:
        logger.info(f"成功下载指数{index_code}的历史数据，共{len(index_data)}条记录")
        logger.info(f"指数数据前5条记录:\n{index_data.head()}")
    else:
        logger.error(f"下载指数{index_code}的历史数据失败")
    
    # 测试获取指数成分股
    logger.info("\n4. 测试获取港股指数成分股")
    index_stocks = downloader.get_index_stocks(index_code)
    if index_stocks:
        logger.info(f"成功获取指数{index_code}的成分股，共{len(index_stocks)}只股票")
        logger.info(f"成分股前10只: {index_stocks[:10]}")
    else:
        logger.error(f"获取指数{index_code}的成分股失败")
    
    logger.info("===== 港股下载器测试完成 =====\n")


def test_us_stock_downloader():
    """
    测试美股下载器功能
    """
    logger.info("===== 开始测试美股下载器 =====")
    
    # 创建下载器实例
    downloader = USStockDownloader()
    
    # 测试获取股票列表
    logger.info("1. 测试获取美股股票列表")
    stock_list = downloader.get_stock_list()
    if not stock_list.empty:
        logger.info(f"成功获取美股股票列表，共{len(stock_list)}只股票")
        logger.info(f"股票列表前5条记录:\n{stock_list.head()}")
    else:
        logger.error("获取美股股票列表失败")
    
    # 测试下载单只股票数据
    logger.info("\n2. 测试下载单只美股股票数据")
    code = 'AAPL'  # 苹果公司
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    if not stock_data.empty:
        logger.info(f"成功下载股票{code}的历史数据，共{len(stock_data)}条记录")
        logger.info(f"股票数据前5条记录:\n{stock_data.head()}")
    else:
        logger.error(f"下载股票{code}的历史数据失败")
    
    # 测试下载指数数据
    logger.info("\n3. 测试下载美股指数数据")
    index_code = '^DJI'  # 道琼斯指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    if not index_data.empty:
        logger.info(f"成功下载指数{index_code}的历史数据，共{len(index_data)}条记录")
        logger.info(f"指数数据前5条记录:\n{index_data.head()}")
    else:
        logger.error(f"下载指数{index_code}的历史数据失败")
    
    # 测试获取指数成分股
    logger.info("\n4. 测试获取美股指数成分股")
    index_stocks = downloader.get_index_stocks(index_code)
    if index_stocks:
        logger.info(f"成功获取指数{index_code}的成分股，共{len(index_stocks)}只股票")
        logger.info(f"成分股前10只: {index_stocks[:10]}")
    else:
        logger.error(f"获取指数{index_code}的成分股失败")
    
    logger.info("===== 美股下载器测试完成 =====\n")


def main():
    """
    主函数，运行所有测试
    """
    logger.info("开始验证股票下载器功能")
    
    # 测试A股下载器
    test_a_stock_downloader()
    
    # 测试港股下载器
    test_hk_stock_downloader()
    
    # 测试美股下载器
    test_us_stock_downloader()
    
    logger.info("所有下载器功能验证完成")


if __name__ == "__main__":
    main()