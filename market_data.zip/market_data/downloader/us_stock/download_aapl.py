#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
# 添加项目根目录到系统路径
root_dir = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, root_dir)

from datetime import datetime, timedelta
from .us_stock_downloader import USStockDownloader
import pandas as pd

if __name__ == '__main__':
    # 创建下载器实例
    downloader = USStockDownloader()
    
    # 计算时间范围（过去一个月）
    end_date = datetime.now().strftime('%Y-%m-%d')
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    
    # 下载AAPL股票数据
    data = downloader.download_stock_data(
        code='AAPL',
        start_date=start_date,
        end_date=end_date,
        adjust=None
    )
    
    # 保存结果到CSV
    if not data.empty:
        data.to_csv('aapl_stock_data.csv')
        print(f'成功下载{len(data)}条记录，已保存到aapl_stock_data.csv')
    else:
        print('未能获取有效数据，请检查日志')