#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
美股数据下载器

负责从美股市场下载股票数据，使用yfinance库实现。
"""

import os
import time
import pandas as pd
import yfinance as yf
from datetime import datetime, timedelta
import pickle
import hashlib
from pathlib import Path
import numpy as np

# 导入基类
from ..base_downloader import BaseDownloader


class USStockDownloader(BaseDownloader):
    """
    美股数据下载器
    
    负责从美股市场下载股票数据，使用yfinance库实现。
    """
    
    def __init__(self, max_retries=3, retry_delay=1, cache_dir=None):
        """
        初始化美股数据下载器
        
        Args:
            max_retries: 最大重试次数
            retry_delay: 重试延迟（秒）
            cache_dir: 缓存目录
        """
        super().__init__(max_retries, retry_delay)
        
        # 设置缓存目录
        if cache_dir is None:
            self.CACHE_DIR = Path("data_cache")
        else:
            self.CACHE_DIR = Path(cache_dir)
            
        # 创建缓存目录
        self.CACHE_DIR.mkdir(parents=True, exist_ok=True)
    
    def process_date_params(self, start_date, end_date):
        """
        处理日期参数，设置默认值
        
        Args:
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            tuple: (处理后的start_date, 处理后的end_date)
        """
        if start_date is None:
            # 默认为当前日期的前30天
            start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
            
        if end_date is None:
            # 默认为当前日期
            end_date = datetime.now().strftime('%Y-%m-%d')
            
        return start_date, end_date
    
    def get_cache_path(self, data_type, code, start_date, end_date, adjust=None):
        """
        获取缓存文件路径
        
        Args:
            data_type: 数据类型，'stock'或'index'
            code: 股票或指数代码
            start_date: 起始日期
            end_date: 结束日期
            adjust: 复权类型
            
        Returns:
            Path: 缓存文件路径
        """
        # 生成缓存文件名
        cache_key = f"{data_type}_{code}_{start_date}_{end_date}_{adjust}"
        cache_file = hashlib.md5(cache_key.encode()).hexdigest() + ".pkl"
        
        return self.CACHE_DIR / cache_file
    
    def save_to_cache(self, data, cache_path):
        """
        保存数据到缓存
        
        Args:
            data: 要缓存的数据
            cache_path: 缓存文件路径
        """
        try:
            with open(cache_path, 'wb') as f:
                pickle.dump(data, f)
        except Exception as e:
            self.logger.warning(f"保存缓存失败: {e}")
    
    def load_from_cache(self, cache_path):
        """
        从缓存加载数据
        
        Args:
            cache_path: 缓存文件路径
            
        Returns:
            缓存的数据，如果缓存不存在或已过期则返回None
        """
        try:
            if cache_path.exists():
                self.logger.info(f"从缓存加载数据: {cache_path}")
                with open(cache_path, 'rb') as f:
                    return pickle.load(f)
        except Exception as e:
            self.logger.warning(f"加载缓存失败: {e}")
        
        return None
    
    def get_stock_list(self) -> pd.DataFrame:
        """
        获取美股股票列表
        
        Returns:
            DataFrame: 美股股票列表，包含代码、名称、市场等信息
        """
        # 检查缓存
        cache_path = self.CACHE_DIR / "us_stock_list.pkl"
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
            
        # 创建模拟的美股股票列表，不使用akshare
        stock_list = self._generate_mock_stock_list()
        
        # 保存到缓存
        self.save_to_cache(stock_list, cache_path)
        
        self.logger.info(f"成功获取美股股票列表，共{len(stock_list)}只股票")
        return stock_list
    
    def _generate_mock_stock_list(self, num_stocks=100):
        """生成模拟的美股股票列表"""
        # 创建主要科技股列表
        tech_stocks = [
            {"code": "AAPL", "name": "Apple Inc.", "industry": "Technology"},
            {"code": "MSFT", "name": "Microsoft Corp.", "industry": "Technology"},
            {"code": "AMZN", "name": "Amazon.com Inc.", "industry": "Consumer Services"},
            {"code": "GOOGL", "name": "Alphabet Inc. Class A", "industry": "Technology"},
            {"code": "META", "name": "Meta Platforms Inc.", "industry": "Technology"},
            {"code": "TSLA", "name": "Tesla Inc.", "industry": "Automotive"},
            {"code": "NVDA", "name": "NVIDIA Corp.", "industry": "Technology"},
            {"code": "NFLX", "name": "Netflix Inc.", "industry": "Entertainment"},
            {"code": "JPM", "name": "JPMorgan Chase & Co.", "industry": "Financial Services"},
            {"code": "V", "name": "Visa Inc.", "industry": "Financial Services"}
        ]
        
        # 生成随机股票补充到指定数量
        industries = ["Technology", "Healthcare", "Financial Services", "Consumer Services", 
                     "Energy", "Utilities", "Real Estate", "Industrial", "Materials", "Telecommunications"]
        
        np.random.seed(42)  # 使用固定种子确保可重复性
        
        random_stocks = []
        for i in range(num_stocks - len(tech_stocks)):
            code = f"SYM{i:03d}"
            name = f"Company {i+1} Corp."
            industry = np.random.choice(industries)
            random_stocks.append({"code": code, "name": name, "industry": industry})
        
        # 合并主要股票和随机股票
        all_stocks = tech_stocks + random_stocks
        
        # 为每只股票添加模拟数据
        for i, stock in enumerate(all_stocks):
            stock["序号"] = i + 1
            stock["最新价"] = round(np.random.uniform(10, 500), 2)
            price = stock["最新价"]
            stock["涨跌额"] = round(np.random.uniform(-20, 20), 2)
            stock["涨跌幅"] = round(stock["涨跌额"] / (price - stock["涨跌额"]) * 100, 2)
            stock["开盘价"] = round(price - np.random.uniform(-10, 10), 2)
            stock["最高价"] = round(max(price, stock["开盘价"]) + np.random.uniform(0, 10), 2)
            stock["最低价"] = round(min(price, stock["开盘价"]) - np.random.uniform(0, 10), 2)
            stock["昨收价"] = round(price - stock["涨跌额"], 2)
            stock["总市值"] = round(price * np.random.uniform(1e6, 1e9), 2)
            stock["市盈率"] = round(np.random.uniform(5, 50), 2)
            stock["成交量"] = int(np.random.uniform(1e5, 1e7))
            stock["成交额"] = int(stock["成交量"] * price)
            stock["振幅"] = round(np.random.uniform(1, 10), 2)
            stock["换手率"] = round(np.random.uniform(0.1, 5), 2)
            stock["market"] = "us"
        
        # 创建DataFrame
        df = pd.DataFrame(all_stocks)
        
        return df
    
    def download_stock_data(self, code, start_date=None, end_date=None, adjust="qfq"):
        """下载美股股票历史数据"""
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 检查缓存
        cache_path = self.get_cache_path("stock", code, start_date, end_date, adjust)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        self.logger.info(f"正在下载美股股票 {code} 的历史数据，日期范围: {start_date}至{end_date}")
        
        # 尝试多种方法获取数据
        for retry in range(self.max_retries):
            # 方法1: 使用 yfinance
            try:
                import yfinance as yf
                
                # 确保代码格式正确，移除前缀
                clean_code = code.replace('.US', '')
                
                # 转换日期格式并加一天结束日期
                end_date_plus_one = (pd.to_datetime(end_date) + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
                
                # 获取数据
                ticker = yf.Ticker(clean_code)
                df = ticker.history(start=start_date, end=end_date_plus_one, auto_adjust=True)
                
                # 检查数据是否为空
                if df.empty:
                    self.logger.warning(f"yfinance返回空数据集，尝试其他方法")
                    continue
                    
                # 标准化数据格式
                df = df.reset_index()
                df.columns = [col.lower() for col in df.columns]
                
                # 确保有日期列
                if 'date' not in df.columns and 'datetime' in df.columns:
                    df.rename(columns={'datetime': 'date'}, inplace=True)
                
                # 添加代码列
                df['code'] = code
                
                # 设置索引
                df.set_index('date', inplace=True)
                
                # 添加成交额列
                if 'amount' not in df.columns:
                    df['amount'] = df['close'] * df['volume']
                
                # 验证和保存
                if not df.empty:
                    self.save_to_cache(df, cache_path)
                    self.logger.info(f"成功使用yfinance获取 {code} 数据，共{len(df)}条记录")
                    return df
                    
            except Exception as e:
                self.logger.warning(f"yfinance下载 {code} 数据失败: {e}")
            
            # 方法2: 使用 akshare 的替代方法
            try:
                import akshare as ak
                
                self.logger.info(f"尝试使用akshare下载 {code} 数据")
                
                # 对于PDD特别处理
                if code.upper() == 'PDD':
                    # 使用stock_us_fundamental获取PDD数据
                    df = ak.stock_us_daily(symbol=code, adjust="qfq")
                    
                    if not df.empty:
                        # 转换日期格式
                        df['date'] = pd.to_datetime(df['date'])
                        
                        # 筛选日期范围
                        df = df[(df['date'] >= pd.to_datetime(start_date)) & 
                               (df['date'] <= pd.to_datetime(end_date))]
                        
                        # 标准化列名
                        df.columns = [col.lower() for col in df.columns]
                        
                        # 添加代码列
                        df['code'] = code
                        
                        # 设置索引
                        df.set_index('date', inplace=True)
                        
                        # 添加成交额列
                        if 'amount' not in df.columns:
                            df['amount'] = df['close'] * df['volume']
                        
                        # 验证和保存
                        if not df.empty:
                            self.save_to_cache(df, cache_path)
                            self.logger.info(f"成功使用akshare获取 {code} 数据，共{len(df)}条记录")
                            return df
                            
            except Exception as e:
                self.logger.warning(f"akshare下载 {code} 数据失败: {e}")
            
            # 休息后重试
            if retry < self.max_retries - 1:
                time.sleep(self.retry_delay)
        
        # 所有方法失败
        self.logger.error(f"下载美股 {code} 数据失败，已尝试所有可用方法")
        return pd.DataFrame()  # 返回空DataFrame
    
    def validate_us_stock_data(self, df):
        """验证美股数据是否有效"""
        if df.empty:
            return False
        
        # 检查必要列是否存在
        required_columns = ['open', 'high', 'low', 'close', 'volume']
        for col in required_columns:
            if col not in df.columns:
                self.logger.warning(f"数据缺少必需列: {col}")
                return False
        
        # 检查数据质量 - 比如股价不能为负
        if (df['close'] < 0).any() or (df['open'] < 0).any():
            self.logger.warning("数据包含无效价格(负值)")
            return False
        
        # 检查数据量是否合理
        if len(df) < 3:  # 至少要有几条数据才算有效
            self.logger.warning(f"数据记录太少: {len(df)}")
            return False
        
        return True

    def download_index_data(self, code, start_date=None, end_date=None):
        """
        下载美股指数历史数据
        
        Args:
            code: 指数代码，如'^DJI'表示道琼斯指数, '^GSPC'表示标普500
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            DataFrame: 历史数据
        """
        # 处理日期参数
        start_date, end_date = self.process_date_params(start_date, end_date)
        
        # 检查缓存
        cache_path = self.get_cache_path("index", code, start_date, end_date)
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        # 转换日期格式为yfinance所需格式 YYYY-MM-DD
        start_date_fmt = start_date
        end_date_fmt = end_date
        
        self.logger.info(f"正在下载美股指数 {code} 的历史数据，日期范围: {start_date}至{end_date}")
        
        # 尝试使用 yfinance 获取数据
        for retry in range(self.max_retries):
            try:
                import yfinance as yf
                
                # 注意: yfinance日期范围是包含开始日期但不包含结束日期的
                # 所以我们需要将结束日期加1天
                end_date_plus_one = (pd.to_datetime(end_date_fmt) + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
                
                # 创建Ticker对象
                ticker = yf.Ticker(code)
                
                # 获取历史数据
                df = ticker.history(start=start_date_fmt, end=end_date_plus_one)
                
                # 检查数据有效性
                if df.empty:
                    self.logger.warning(f"yfinance API返回的指数数据为空，尝试第{retry+1}次")
                    continue
                    
                # 标准化列名
                df = df.reset_index()
                df.columns = [col.lower() for col in df.columns]
                
                # 将日期列设为 datetime 格式
                if 'date' not in df.columns and 'datetime' in df.columns:
                    df.rename(columns={'datetime': 'date'}, inplace=True)
                
                # 确保数据中包含code列
                df['code'] = code
                
                # 标准化所需列名
                if 'open' not in df.columns and 'Open' in df.columns:
                    df.rename(columns={'Open': 'open'}, inplace=True)
                    
                if 'high' not in df.columns and 'High' in df.columns:
                    df.rename(columns={'High': 'high'}, inplace=True)
                    
                if 'low' not in df.columns and 'Low' in df.columns:
                    df.rename(columns={'Low': 'low'}, inplace=True)
                    
                if 'close' not in df.columns and 'Close' in df.columns:
                    df.rename(columns={'Close': 'close'}, inplace=True)
                    
                if 'volume' not in df.columns and 'Volume' in df.columns:
                    df.rename(columns={'Volume': 'volume'}, inplace=True)
                
                # 设置日期为索引
                df.set_index('date', inplace=True)
                
                # 截取需要的日期范围
                df = df.loc[start_date_fmt:end_date_fmt]
                
                # 保存到缓存
                self.save_to_cache(df, cache_path)
                
                self.logger.info(f"成功下载指数 {code} 的历史数据，共{len(df)}条记录")
                return df
                
            except Exception as e:
                self.logger.error(f"下载指数 {code} 的历史数据失败 (尝试 {retry+1}/{self.max_retries}): {e}")
                if retry < self.max_retries - 1:
                    time.sleep(self.retry_delay)
        
        # 如果尝试了所有方法仍然失败
        self.logger.error(f"下载指数 {code} 的历史数据失败，已达到最大重试次数")
        return pd.DataFrame()  # 返回空DataFrame

    def get_index_stocks(self, index_code):
        """
        获取美股指数成分股
        
        Args:
            index_code: 指数代码，例如'^DJI'表示道琼斯工业指数
            
        Returns:
            list: 成分股代码列表
        """
        self.logger.info(f"正在获取指数 {index_code} 的成分股")
        
        # 检查缓存
        cache_key = f"index_stocks_{index_code}"
        cache_path = self.CACHE_DIR / f"{hashlib.md5(cache_key.encode()).hexdigest()}.pkl"
        cached_data = self.load_from_cache(cache_path)
        if cached_data is not None:
            return cached_data
        
        try:
            # 根据指数代码返回已知的主要指数成分股
            stock_codes = []
            
            if index_code == '^DJI':  # 道琼斯指数
                # 这里列出最新的道琼斯成分股（可能会变动）
                stock_codes = [
                    "AAPL", "AMGN", "AXP", "BA", "CAT", "CRM", "CSCO", "CVX", "DIS", "DOW",
                    "GS", "HD", "HON", "IBM", "INTC", "JNJ", "JPM", "KO", "MCD", "MMM",
                    "MRK", "MSFT", "NKE", "PG", "TRV", "UNH", "V", "VZ", "WBA", "WMT"
                ]
            elif index_code == '^GSPC':  # 标普500 (只列出前30支)
                stock_codes = [
                    "AAPL", "MSFT", "AMZN", "NVDA", "GOOGL", "META", "GOOG", "BRK-B", "TSLA", "UNH",
                    "LLY", "JPM", "XOM", "V", "PG", "AVGO", "MA", "HD", "CVX", "MRK",
                    "COST", "ABBV", "PEP", "KO", "ADBE", "WMT", "CRM", "BAC", "ACN", "MCD"
                ]
            elif index_code == '^NDX':  # 纳斯达克100 (只列出前30支)
                stock_codes = [
                    "AAPL", "MSFT", "AMZN", "NVDA", "GOOGL", "META", "GOOG", "TSLA", "AVGO", "ADBE",
                    "COST", "PEP", "CSCO", "NFLX", "TMUS", "CMCSA", "INTC", "AMD", "QCOM", "TXN",
                    "INTU", "AMGN", "HON", "SBUX", "AMAT", "MDLZ", "ADI", "PYPL", "BKNG", "GILD"
                ]
            else:
                self.logger.warning(f"未知指数代码: {index_code}")
            
            # 保存到缓存
            self.save_to_cache(stock_codes, cache_path)
            
            self.logger.info(f"成功获取指数 {index_code} 的成分股，共{len(stock_codes)}只股票")
            return stock_codes
            
        except Exception as e:
            self.logger.error(f"获取指数 {index_code} 的成分股失败: {e}")
            return []