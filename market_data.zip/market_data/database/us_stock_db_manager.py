def get_latest_date(self, code):
    """
    获取指定股票的最新数据日期
    
    Args:
        code: 股票代码
        
    Returns:
        str: 最新数据日期，格式为'YYYY-MM-DD'，如果没有数据则返回None
    """
    try:
        # 确保数据库连接
        self._ensure_connection()
        
        # 执行查询
        cursor = self.connection.cursor()
        cursor.execute("""
            SELECT MAX(date) FROM stock_data
            WHERE code = ?
        """, (code,))
        
        result = cursor.fetchone()
        if result and result[0]:
            # 返回日期字符串格式
            return result[0]
        return None
        
    except Exception as e:
        self.logger.error(f"获取股票 {code} 最新日期失败: {e}")
        return None 