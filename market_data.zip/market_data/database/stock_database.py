#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
统一股票数据库管理器
处理所有市场(A股、港股、美股)的数据存储和检索
"""

import os
import sqlite3
import pandas as pd
from datetime import datetime
import logging

# 导入日志工具
from ..utils.log_utils import get_logger


class StockDatabase:
    """统一股票数据库管理器"""
    
    def __init__(self, db_path=None):
        """
        初始化数据库管理器
        
        Args:
            db_path: 数据库文件路径，默认为'data/stock_data.db'
        """
        # 设置数据库路径
        if db_path is None:
            # 确保data目录存在
            os.makedirs("data", exist_ok=True)
            self.db_path = os.path.join("data", "stock_data.db")
        else:
            self.db_path = db_path
            
        # 获取日志记录器
        self.logger = get_logger("StockDatabase")
        
        # 初始化数据库连接
        self.connection = None
        self._init_database()
    
    def _init_database(self):
        """初始化数据库，创建必要的表"""
        try:
            # 创建数据库连接
            self._ensure_connection()
            
            # 创建股票数据表
            cursor = self.connection.cursor()
            
            # 股票基本信息表 - 所有市场共用
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stock_info (
                    code TEXT PRIMARY KEY,
                    name TEXT,
                    market TEXT,
                    industry TEXT,
                    last_updated TEXT
                )
            """)
            
            # 股票价格数据表 - 带市场区分
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stock_data (
                    code TEXT,
                    date TEXT,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    volume REAL,
                    amount REAL,
                    market TEXT,
                    PRIMARY KEY (code, date, market)
                )
            """)
            
            # 指数数据表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS index_data (
                    code TEXT,
                    date TEXT,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    volume REAL,
                    amount REAL,
                    market TEXT,
                    PRIMARY KEY (code, date, market)
                )
            """)
            
            # 指数成分股关系表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS index_components (
                    index_code TEXT,
                    stock_code TEXT,
                    market TEXT,
                    weight REAL,
                    last_updated TEXT,
                    PRIMARY KEY (index_code, stock_code, market)
                )
            """)
            
            self.connection.commit()
            self.logger.info("数据库初始化成功")
            
        except Exception as e:
            self.logger.error(f"初始化数据库失败: {e}")
            raise
    
    def _ensure_connection(self):
        """确保数据库连接有效"""
        if self.connection is None:
            self.connection = sqlite3.connect(self.db_path)
            # 启用外键约束
            self.connection.execute("PRAGMA foreign_keys = ON")
    
    def close(self):
        """关闭数据库连接"""
        if self.connection:
            self.connection.close()
            self.connection = None
    
    # 通用方法，适用于所有市场
    def save_stock_data(self, data, market_type='A'):
        """
        保存股票数据到数据库
        
        Args:
            data: DataFrame, 包含股票数据
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            
        Returns:
            int: 保存的记录数
        """
        try:
            if data.empty:
                self.logger.warning("没有数据需要保存")
                return 0
                
            # 确保数据库连接
            self._ensure_connection()
            
            # 准备数据
            df = data.reset_index() if 'date' not in data.columns else data.copy()
            
            # 确保日期列格式正确
            if 'date' in df.columns:
                df['date'] = pd.to_datetime(df['date']).dt.strftime('%Y-%m-%d')
            
            # 添加市场信息
            df['market'] = market_type
            
            # 将数据插入数据库
            count = 0
            for _, row in df.iterrows():
                try:
                    cursor = self.connection.cursor()
                    
                    # 检查是否已存在相同记录
                    cursor.execute("""
                        SELECT COUNT(*) FROM stock_data
                        WHERE code = ? AND date = ? AND market = ?
                    """, (row['code'], row['date'], market_type))
                    
                    if cursor.fetchone()[0] > 0:
                        # 更新现有记录
                        cursor.execute("""
                            UPDATE stock_data SET
                            open = ?, high = ?, low = ?, close = ?,
                            volume = ?, amount = ?
                            WHERE code = ? AND date = ? AND market = ?
                        """, (
                            row.get('open', 0), row.get('high', 0), row.get('low', 0), row.get('close', 0),
                            row.get('volume', 0), row.get('amount', 0),
                            row['code'], row['date'], market_type
                        ))
                    else:
                        # 插入新记录
                        cursor.execute("""
                            INSERT INTO stock_data
                            (code, date, open, high, low, close, volume, amount, market)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """, (
                            row['code'], row['date'],
                            row.get('open', 0), row.get('high', 0), row.get('low', 0), row.get('close', 0),
                            row.get('volume', 0), row.get('amount', 0),
                            market_type
                        ))
                    
                    count += 1
                except Exception as e:
                    self.logger.error(f"保存记录失败: {e}, 数据: {row}")
                    continue
            
            # 提交事务
            self.connection.commit()
            self.logger.info(f"成功保存 {count} 条股票数据记录")
            return count
            
        except Exception as e:
            self.logger.error(f"保存股票数据失败: {e}")
            return 0
    
    def get_stock_data(self, code, start_date=None, end_date=None, market_type='A'):
        """
        从数据库获取股票数据
        
        Args:
            code: 股票代码
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            market_type: 市场类型
            
        Returns:
            DataFrame: 股票历史数据
        """
        try:
            # 确保数据库连接
            self._ensure_connection()
            
            # 构建查询
            query = """
                SELECT * FROM stock_data
                WHERE code = ? AND market = ?
            """
            
            params = [code, market_type]
            
            if start_date:
                query += " AND date >= ?"
                params.append(start_date)
                
            if end_date:
                query += " AND date <= ?"
                params.append(end_date)
                
            query += " ORDER BY date"
            
            # 执行查询
            df = pd.read_sql_query(query, self.connection, params=params)
            
            # 如果没有数据，返回空DataFrame
            if df.empty:
                return pd.DataFrame()
                
            # 设置日期为索引
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
            
            return df
            
        except Exception as e:
            self.logger.error(f"获取股票 {code} 数据失败: {e}")
            return pd.DataFrame()
    
    def get_latest_date(self, code, market_type='A'):
        """
        获取指定股票的最新数据日期
        
        Args:
            code: 股票代码
            market_type: 市场类型
            
        Returns:
            str: 最新数据日期，格式为'YYYY-MM-DD'，如果没有数据则返回None
        """
        try:
            # 确保数据库连接
            self._ensure_connection()
            
            # 执行查询
            cursor = self.connection.cursor()
            cursor.execute("""
                SELECT MAX(date) FROM stock_data
                WHERE code = ? AND market = ?
            """, (code, market_type))
            
            result = cursor.fetchone()
            if result and result[0]:
                # 返回日期字符串格式
                return result[0]
            return None
            
        except Exception as e:
            self.logger.error(f"获取股票 {code} 最新日期失败: {e}")
            return None
    
    def save_stock_list(self, stock_list, market_type='A'):
        """
        保存股票列表
        
        Args:
            stock_list: DataFrame, 包含股票代码、名称等信息
            market_type: 市场类型
            
        Returns:
            int: 保存的记录数
        """
        try:
            if stock_list.empty:
                self.logger.warning("没有股票列表数据需要保存")
                return 0
                
            # 确保数据库连接
            self._ensure_connection()
            
            # 准备数据
            count = 0
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            
            for _, row in stock_list.iterrows():
                try:
                    code = row.get('code', '')
                    name = row.get('name', '')
                    industry = row.get('industry', '')
                    
                    if not code:
                        continue
                        
                    cursor = self.connection.cursor()
                    
                    # 检查是否已存在
                    cursor.execute("""
                        SELECT COUNT(*) FROM stock_info
                        WHERE code = ?
                    """, (code,))
                    
                    if cursor.fetchone()[0] > 0:
                        # 更新现有记录
                        cursor.execute("""
                            UPDATE stock_info SET
                            name = ?, market = ?, industry = ?, last_updated = ?
                            WHERE code = ?
                        """, (name, market_type, industry, current_time, code))
                    else:
                        # 插入新记录
                        cursor.execute("""
                            INSERT INTO stock_info
                            (code, name, market, industry, last_updated)
                            VALUES (?, ?, ?, ?, ?)
                        """, (code, name, market_type, industry, current_time))
                    
                    count += 1
                except Exception as e:
                    self.logger.error(f"保存股票信息失败: {e}, 数据: {row}")
                    continue
            
            # 提交事务
            self.connection.commit()
            self.logger.info(f"成功保存 {count} 条股票信息记录")
            return count
            
        except Exception as e:
            self.logger.error(f"保存股票列表失败: {e}")
            return 0
    
    def get_stock_list(self, market_type=None):
        """
        获取股票列表
        
        Args:
            market_type: 市场类型，None表示获取所有市场
            
        Returns:
            DataFrame: 股票列表
        """
        try:
            # 确保数据库连接
            self._ensure_connection()
            
            # 构建查询
            query = "SELECT * FROM stock_info"
            params = []
            
            if market_type:
                query += " WHERE market = ?"
                params.append(market_type)
                
            # 执行查询
            df = pd.read_sql_query(query, self.connection, params=params)
            
            return df
            
        except Exception as e:
            self.logger.error(f"获取股票列表失败: {e}")
            return pd.DataFrame() 