#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据配置模块

存储各个市场的配置信息，如数据库路径、日志设置等。
"""

import os

# 项目根目录
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 数据库目录
DATABASE_DIR = os.path.join(ROOT_DIR, 'database')

# 日志目录
LOG_DIR = os.path.join(ROOT_DIR, 'logs')

# 确保目录存在
os.makedirs(DATABASE_DIR, exist_ok=True)
os.makedirs(LOG_DIR, exist_ok=True)

# A股配置
A_STOCK_CONFIG = {
    'database_dir': os.path.join(DATABASE_DIR, 'a_stock'),
    'stock_info_db': os.path.join(DATABASE_DIR, 'a_stock', 'stock_info.db'),
    'stock_data_db': os.path.join(DATABASE_DIR, 'a_stock', 'stock_data.db'),
    'log_file': os.path.join(LOG_DIR, 'a_stock.log'),
}

# 港股配置
HK_STOCK_CONFIG = {
    'database_dir': os.path.join(DATABASE_DIR, 'hk_stock'),
    'stock_info_db': os.path.join(DATABASE_DIR, 'hk_stock', 'stock_info.db'),
    'stock_data_db': os.path.join(DATABASE_DIR, 'hk_stock', 'stock_data.db'),
    'log_file': os.path.join(LOG_DIR, 'hk_stock.log'),
}

# 美股配置
US_STOCK_CONFIG = {
    'database_dir': os.path.join(DATABASE_DIR, 'us_stock'),
    'stock_info_db': os.path.join(DATABASE_DIR, 'us_stock', 'stock_info.db'),
    'stock_data_db': os.path.join(DATABASE_DIR, 'us_stock', 'stock_data.db'),
    'log_file': os.path.join(LOG_DIR, 'us_stock.log'),
}

# 确保各市场数据库目录存在
os.makedirs(A_STOCK_CONFIG['database_dir'], exist_ok=True)
os.makedirs(HK_STOCK_CONFIG['database_dir'], exist_ok=True)
os.makedirs(US_STOCK_CONFIG['database_dir'], exist_ok=True)