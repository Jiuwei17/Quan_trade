#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据日志模块

提供日志记录功能，用于记录各个市场数据下载和管理过程中的信息。
"""

import os
import logging
from .config import LOG_DIR

# 确保日志目录存在
os.makedirs(LOG_DIR, exist_ok=True)

def setup_logger(name, log_file=None, level=logging.INFO):
    """
    设置日志记录器
    
    Args:
        name: 日志记录器名称
        log_file: 日志文件路径，如果为None，则只输出到控制台
        level: 日志级别
        
    Returns:
        Logger: 配置好的日志记录器
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 如果没有处理器，添加处理器
    if not logger.handlers:
        # 控制台处理器
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        console_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)
        
        # 文件处理器
        if log_file:
            file_handler = logging.FileHandler(log_file, 'a')
            file_handler.setLevel(level)
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)
    
    return logger

# 创建默认日志记录器
default_logger = setup_logger('market_data', os.path.join(LOG_DIR, 'market_data.log'))

def get_logger(name=None, log_file=None):
    """
    获取日志记录器
    
    Args:
        name: 日志记录器名称，如果为None，则使用默认日志记录器
        log_file: 日志文件路径，如果为None，则使用默认日志文件
        
    Returns:
        Logger: 日志记录器
    """
    if name is None:
        return default_logger
    
    if log_file is None:
        log_file = os.path.join(LOG_DIR, f"{name}.log")
    
    return setup_logger(name, log_file)