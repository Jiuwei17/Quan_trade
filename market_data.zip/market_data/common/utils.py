#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据工具模块

提供一些通用的工具函数，用于辅助市场数据的下载和管理。
"""

import os
import pandas as pd
from datetime import datetime, timedelta


def format_date(date_str):
    """
    格式化日期字符串为标准格式 'YYYY-MM-DD'
    
    Args:
        date_str: 日期字符串，可以是多种格式
        
    Returns:
        str: 格式化后的日期字符串，格式为'YYYY-MM-DD'
    """
    if date_str is None:
        return None
    
    # 如果已经是标准格式，直接返回
    if isinstance(date_str, str) and len(date_str) == 10 and date_str[4] == '-' and date_str[7] == '-':
        return date_str
    
    # 如果是datetime对象，转换为字符串
    if isinstance(date_str, datetime):
        return date_str.strftime('%Y-%m-%d')
    
    # 如果是YYYYMMDD格式，转换为YYYY-MM-DD
    if isinstance(date_str, str) and len(date_str) == 8 and date_str.isdigit():
        return f"{date_str[:4]}-{date_str[4:6]}-{date_str[6:]}"
    
    # 尝试解析其他格式
    try:
        return pd.to_datetime(date_str).strftime('%Y-%m-%d')
    except:
        raise ValueError(f"无法解析日期格式: {date_str}")


def get_date_range(start_date=None, end_date=None, days=30):
    """
    获取日期范围
    
    Args:
        start_date: 起始日期，如果为None，则为end_date前days天
        end_date: 结束日期，如果为None，则为今天
        days: 天数，默认为30天
        
    Returns:
        tuple: (start_date, end_date)，格式为'YYYY-MM-DD'
    """
    # 处理结束日期
    if end_date is None:
        end_date = datetime.now().strftime('%Y-%m-%d')
    else:
        end_date = format_date(end_date)
    
    # 处理起始日期
    if start_date is None:
        end_date_obj = datetime.strptime(end_date, '%Y-%m-%d')
        start_date = (end_date_obj - timedelta(days=days)).strftime('%Y-%m-%d')
    else:
        start_date = format_date(start_date)
    
    return start_date, end_date


def is_valid_stock_code(code, market_type='A'):
    """
    检查股票代码是否有效
    
    Args:
        code: 股票代码
        market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
        
    Returns:
        bool: 是否有效
    """
    if not code:
        return False
    
    if market_type == 'A':
        # A股股票代码为6位数字
        return isinstance(code, str) and len(code) == 6 and code.isdigit()
    elif market_type == 'HK':
        # 港股股票代码为5位数字或4位数字
        return isinstance(code, str) and (len(code) == 5 or len(code) == 4) and code.isdigit()
    elif market_type == 'US':
        # 美股股票代码为字母或字母+数字组合
        return isinstance(code, str) and len(code) > 0 and code.isalnum()
    else:
        return False


def get_market_type_by_code(code):
    """
    根据股票代码判断市场类型
    
    Args:
        code: 股票代码
        
    Returns:
        str: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股，None表示无法判断
    """
    if not code:
        return None
    
    # A股股票代码为6位数字
    if isinstance(code, str) and len(code) == 6 and code.isdigit():
        return 'A'
    
    # 港股股票代码为5位数字或4位数字
    if isinstance(code, str) and (len(code) == 5 or len(code) == 4) and code.isdigit():
        return 'HK'
    
    # 美股股票代码为字母或字母+数字组合
    if isinstance(code, str) and len(code) > 0 and code.isalnum() and not code.isdigit():
        return 'US'
    
    return None


def create_directory_if_not_exists(directory):
    """
    如果目录不存在，则创建目录
    
    Args:
        directory: 目录路径
    """
    if not os.path.exists(directory):
        os.makedirs(directory, exist_ok=True)