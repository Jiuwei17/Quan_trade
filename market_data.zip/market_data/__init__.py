#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
股票市场数据下载模块

此模块负责从各个市场（A股、港股、美股）下载股票数据，并实现增量更新机制。
A股和港股使用akshare库，美股使用yfinance库。
每个市场有独立的下载器和数据库，确保数据隔离和便于维护。

主要功能：
1. 获取股票列表（A股、港股、美股）
2. 下载股票历史数据（支持增量更新）
3. 下载指数历史数据
4. 数据存储到独立的数据库
"""

# 导出统一API接口
from .api.market_data_api import MarketDataAPI

# 导出各市场下载器
from .downloader.a_stock.a_stock_downloader import AStockDownloader
from .downloader.hk_stock.hk_stock_downloader import HKStockDownloader
from .downloader.us_stock.us_stock_downloader import USStockDownloader

# 导出数据库管理器
from .database_manager.a_stock_db_manager import AStockDBManager
from .database_manager.hk_stock_db_manager import HKStockDBManager
from .database_manager.us_stock_db_manager import USStockDBManager

__all__ = [
    'MarketDataAPI',
    'AStockDownloader',
    'HKStockDownloader',
    'USStockDownloader',
    'AStockDBManager',
    'HKStockDBManager',
    'USStockDBManager',
]