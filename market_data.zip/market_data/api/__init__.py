#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据API模块

提供统一的接口来访问A股、港股和美股的数据。
"""

from .market_data_api import MarketDataAPI

__all__ = ['MarketDataAPI']