#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据统一API接口

提供统一的接口来访问A股、港股和美股的数据，简化数据获取和管理过程。
"""

import os
import pandas as pd
from datetime import datetime, timedelta

# 导入各市场下载器和数据库管理器
from ..downloader.a_stock.a_stock_downloader import AStockDownloader
from ..downloader.hk_stock.hk_stock_downloader import HKStockDownloader
from ..downloader.us_stock.us_stock_downloader import USStockDownloader

from ..database_manager.a_stock_db_manager import AStockDBManager
from ..database_manager.hk_stock_db_manager import HKStockDBManager
from ..database_manager.us_stock_db_manager import USStockDBManager


class MarketDataAPI:
    """
    市场数据统一API接口
    
    提供统一的接口来访问A股、港股和美股的数据，简化数据获取和管理过程。
    """
    
    def __init__(self):
        """
        初始化市场数据API
        
        创建各市场的下载器和数据库管理器实例
        """
        # 创建下载器实例
        self.a_stock_downloader = AStockDownloader()
        self.hk_stock_downloader = HKStockDownloader()
        self.us_stock_downloader = USStockDownloader()
        
        # 创建数据库管理器实例
        self.a_stock_db_manager = AStockDBManager()
        self.hk_stock_db_manager = HKStockDBManager()
        self.us_stock_db_manager = USStockDBManager()
        
        # 市场类型映射
        self.market_types = {
            'A': 'a_stock',
            'HK': 'hk_stock',
            'US': 'us_stock'
        }
    
    def _get_downloader(self, market_type):
        """
        获取指定市场的下载器
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            
        Returns:
            BaseDownloader: 对应市场的下载器实例
        """
        if market_type == 'A':
            return self.a_stock_downloader
        elif market_type == 'HK':
            return self.hk_stock_downloader
        elif market_type == 'US':
            return self.us_stock_downloader
        else:
            raise ValueError(f"不支持的市场类型: {market_type}，支持的类型有: A, HK, US")
    
    def _get_db_manager(self, market_type):
        """
        获取指定市场的数据库管理器
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            
        Returns:
            BaseDBManager: 对应市场的数据库管理器实例
        """
        if market_type == 'A':
            return self.a_stock_db_manager
        elif market_type == 'HK':
            return self.hk_stock_db_manager
        elif market_type == 'US':
            return self.us_stock_db_manager
        else:
            raise ValueError(f"不支持的市场类型: {market_type}，支持的类型有: A, HK, US")
    
    def get_stock_list(self, market_type='A'):
        """
        获取指定市场的股票列表
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            
        Returns:
            DataFrame: 股票列表
        """
        downloader = self._get_downloader(market_type)
        return downloader.get_stock_list()
    
    def download_stock_data(self, code, market_type='A', start_date=None, end_date=None, adjust="qfq", save_to_db=True):
        """
        下载指定市场的股票历史数据
        
        Args:
            code: 股票代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            adjust: 复权类型，'qfq'表示前复权，'hfq'表示后复权，None表示不复权
            save_to_db: 是否保存到数据库
            
        Returns:
            DataFrame: 历史数据
        """
        downloader = self._get_downloader(market_type)
        data = downloader.download_stock_data(code, start_date, end_date, adjust)
        
        if save_to_db and not data.empty:
            db_manager = self._get_db_manager(market_type)
            db_manager.save_stock_data(data)
        
        return data
    
    def download_index_data(self, code, market_type='A', start_date=None, end_date=None, save_to_db=True):
        """
        下载指定市场的指数历史数据
        
        Args:
            code: 指数代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            save_to_db: 是否保存到数据库
            
        Returns:
            DataFrame: 历史数据
        """
        downloader = self._get_downloader(market_type)
        data = downloader.download_index_data(code, start_date, end_date)
        
        if save_to_db and not data.empty:
            db_manager = self._get_db_manager(market_type)
            db_manager.save_stock_data(data)
        
        return data
    
    def get_index_stocks(self, index_code, market_type='A', save_to_db=True):
        """
        获取指定市场的指数成分股
        
        Args:
            index_code: 指数代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            save_to_db: 是否保存到数据库
            
        Returns:
            list: 成分股代码列表
        """
        downloader = self._get_downloader(market_type)
        stock_codes = downloader.get_index_stocks(index_code)
        
        if save_to_db and stock_codes:
            db_manager = self._get_db_manager(market_type)
            db_manager.save_index_stocks(index_code, stock_codes)
        
        return stock_codes
    
    def get_stock_data(self, code, market_type='A', start_date=None, end_date=None):
        """
        从数据库获取股票数据
        
        Args:
            code: 股票代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            DataFrame: 股票数据
        """
        db_manager = self._get_db_manager(market_type)
        return db_manager.get_stock_data(code, start_date, end_date)
    
    def get_latest_trading_date(self, market_type='A', code=None):
        """
        获取最新交易日期
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            code: 股票代码，如果为None，则获取所有股票的最新交易日期
            
        Returns:
            str: 最新交易日期，格式：'YYYY-MM-DD'
        """
        db_manager = self._get_db_manager(market_type)
        return db_manager.get_latest_trading_date(code)
    
    def get_stock_data_update_status(self, market_type='A'):
        """
        获取股票数据更新状态
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            
        Returns:
            DataFrame: 股票数据更新状态
        """
        db_manager = self._get_db_manager(market_type)
        return db_manager.get_stock_data_update_status()
    
    def update_stock_data(self, code, market_type='A', days=30, adjust="qfq"):
        """
        增量更新股票数据
        
        Args:
            code: 股票代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            days: 如果股票没有历史数据，下载最近days天的数据
            adjust: 复权类型，'qfq'表示前复权，'hfq'表示后复权，None表示不复权
            
        Returns:
            bool: 是否成功更新
        """
        # 获取数据库管理器和下载器
        db_manager = self._get_db_manager(market_type)
        downloader = self._get_downloader(market_type)
        
        # 获取最新交易日期
        latest_date = db_manager.get_latest_trading_date(code)
        
        # 确定下载日期范围
        end_date = datetime.now().strftime('%Y-%m-%d')
        if latest_date is None:
            # 如果没有数据，则下载最近days天的数据
            start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
            self.logger.info(f"股票 {code} 没有历史数据，将下载最近 {days} 天的数据")
        else:
            # 有数据，则从最新日期后一天开始下载
            latest_date_obj = datetime.strptime(latest_date, '%Y-%m-%d')
            start_date = (latest_date_obj + timedelta(days=1)).strftime('%Y-%m-%d')
            self.logger.info(f"股票 {code} 最新数据日期为 {latest_date}，将下载 {start_date} 至今的增量数据")
            
            # 如果最新日期是今天或未来日期，无需更新
            if start_date > end_date:
                self.logger.info(f"股票 {code} 数据已是最新，无需更新")
                return True
        
        # 下载数据
        self.logger.info(f"下载股票 {code} 数据，日期范围: {start_date} 至 {end_date}")
        data = downloader.download_stock_data(code, start_date, end_date, adjust)
        
        # 保存数据到数据库
        if not data.empty:
            db_manager.save_stock_data(data)
            self.logger.info(f"股票 {code} 数据更新成功，新增 {len(data)} 条记录")
            return True
        else:
            self.logger.warning(f"股票 {code} 在指定日期范围内没有新数据")
            return False
    
    def update_index_data(self, code, market_type='A', days=30):
        """
        更新指数数据
        
        Args:
            code: 指数代码
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            days: 更新天数，默认为30天
            
        Returns:
            bool: 更新是否成功
        """
        # 获取最新交易日期
        db_manager = self._get_db_manager(market_type)
        latest_date = db_manager.get_latest_trading_date(code)
        
        # 如果没有数据，则下载最近days天的数据
        if latest_date is None:
            end_date = datetime.now().strftime('%Y-%m-%d')
            start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
        else:
            # 如果有数据，则从最新日期后一天开始下载
            latest_date_obj = datetime.strptime(latest_date, '%Y-%m-%d')
            start_date = (latest_date_obj + timedelta(days=1)).strftime('%Y-%m-%d')
            end_date = datetime.now().strftime('%Y-%m-%d')
        
        # 下载数据
        downloader = self._get_downloader(market_type)
        data = downloader.download_index_data(code, start_date, end_date)
        
        # 保存数据到数据库
        if not data.empty:
            db_manager.save_stock_data(data)
            return True
        
        return False
    
    def batch_update_stocks(self, market_type='A', stock_codes=None, days=30, adjust="qfq"):
        """
        批量更新股票数据
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            stock_codes: 股票代码列表，如果为None，则更新所有股票
            days: 更新天数，默认为30天
            adjust: 复权类型，'qfq'表示前复权，'hfq'表示后复权，None表示不复权
            
        Returns:
            dict: 更新结果统计
        """
        db_manager = self._get_db_manager(market_type)
        
        # 如果没有指定股票代码，则获取所有股票代码
        if stock_codes is None:
            stock_codes = db_manager.get_stock_codes()
        
        # 统计结果
        result = {
            'total': len(stock_codes),
            'success': 0,
            'failed': 0,
            'skipped': 0
        }
        
        # 批量更新
        for code in stock_codes:
            try:
                # 获取最新交易日期
                latest_date = db_manager.get_latest_trading_date(code)
                
                # 如果没有数据，则下载最近days天的数据
                if latest_date is None:
                    end_date = datetime.now().strftime('%Y-%m-%d')
                    start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
                else:
                    # 如果有数据，则从最新日期后一天开始下载
                    latest_date_obj = datetime.strptime(latest_date, '%Y-%m-%d')
                    start_date = (latest_date_obj + timedelta(days=1)).strftime('%Y-%m-%d')
                    end_date = datetime.now().strftime('%Y-%m-%d')
                    
                    # 如果最新日期是今天，则跳过
                    if start_date >= end_date:
                        result['skipped'] += 1
                        continue
                
                # 下载数据
                downloader = self._get_downloader(market_type)
                data = downloader.download_stock_data(code, start_date, end_date, adjust)
                
                # 保存数据到数据库
                if not data.empty:
                    db_manager.save_stock_data(data)
                    result['success'] += 1
                else:
                    result['skipped'] += 1
                    
            except Exception as e:
                print(f"更新股票 {code} 数据失败: {e}")
                result['failed'] += 1
        
        return result
    
    def batch_update_indices(self, market_type='A', index_codes=None, days=30):
        """
        批量更新指数数据
        
        Args:
            market_type: 市场类型，'A'表示A股，'HK'表示港股，'US'表示美股
            index_codes: 指数代码列表，如果为None，则更新所有指数
            days: 更新天数，默认为30天
            
        Returns:
            dict: 更新结果统计
        """
        db_manager = self._get_db_manager(market_type)
        
        # 如果没有指定指数代码，则获取所有指数代码
        if index_codes is None:
            index_codes = db_manager.get_index_codes()
        
        # 统计结果
        result = {
            'total': len(index_codes),
            'success': 0,
            'failed': 0,
            'skipped': 0
        }
        
        # 批量更新
        for code in index_codes:
            try:
                # 获取最新交易日期
                latest_date = db_manager.get_latest_trading_date(code)
                
                # 如果没有数据，则下载最近days天的数据
                if latest_date is None:
                    end_date = datetime.now().strftime('%Y-%m-%d')
                    start_date = (datetime.now() - timedelta(days=days)).strftime('%Y-%m-%d')
                else:
                    # 如果有数据，则从最新日期后一天开始下载
                    latest_date_obj = datetime.strptime(latest_date, '%Y-%m-%d')
                    start_date = (latest_date_obj + timedelta(days=1)).strftime('%Y-%m-%d')
                    end_date = datetime.now().strftime('%Y-%m-%d')
                    
                    # 如果最新日期是今天，则跳过
                    if start_date >= end_date:
                        result['skipped'] += 1
                        continue
                
                # 下载数据
                downloader = self._get_downloader(market_type)
                data = downloader.download_index_data(code, start_date, end_date)
                
                # 保存数据到数据库
                if not data.empty:
                    db_manager.save_stock_data(data)
                    result['success'] += 1
                else:
                    result['skipped'] += 1
                    
            except Exception as e:
                print(f"更新指数 {code} 数据失败: {e}")
                result['failed'] += 1
        
        return result