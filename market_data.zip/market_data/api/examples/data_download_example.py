#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
市场数据下载示例脚本

展示如何使用市场数据API下载A股、港股和美股的数据。
"""

import os
import sys
import pandas as pd
from datetime import datetime, timedelta

# 添加项目根目录到系统路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(project_root)

# 导入市场数据API
from market_data.downloader.a_stock.a_stock_downloader import AStockDownloader
from market_data.downloader.hk_stock.hk_stock_downloader import HKStockDownloader
from market_data.downloader.us_stock.us_stock_downloader import USStockDownloader
from market_data.database_manager.a_stock_db_manager import AStockDBManager
from market_data.database_manager.hk_stock_db_manager import HKStockDBManager
from market_data.database_manager.us_stock_db_manager import USStockDBManager


def download_a_stock_data():
    """
    下载A股数据示例
    """
    print("\n===== 下载A股数据示例 =====")
    
    # 创建A股下载器和数据库管理器
    downloader = AStockDownloader()
    db_manager = AStockDBManager()
    
    # 获取股票列表
    print("\n1. 获取A股股票列表")
    stock_list = downloader.get_stock_list()
    print(f"获取到 {len(stock_list)} 只A股股票")
    print(stock_list.head())
    
    # 保存股票列表到数据库
    db_manager.save_stock_list(stock_list)
    
    # 下载单只股票数据
    print("\n2. 下载单只A股股票数据（以贵州茅台为例）")
    code = '600519'  # 贵州茅台
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    print(f"下载到 {len(stock_data)} 条数据记录")
    print(stock_data.head())
    
    # 保存股票数据到数据库
    db_manager.save_stock_data(stock_data)
    
    # 下载指数数据
    print("\n3. 下载A股指数数据（以上证指数为例）")
    index_code = '000001'  # 上证指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    print(f"下载到 {len(index_data)} 条数据记录")
    print(index_data.head())
    
    # 保存指数数据到数据库
    db_manager.save_stock_data(index_data)
    
    # 获取指数成分股
    print("\n4. 获取指数成分股（以沪深300为例）")
    index_code = '000300'  # 沪深300
    index_stocks = downloader.get_index_stocks(index_code)
    print(f"获取到 {len(index_stocks)} 只成分股")
    print(index_stocks[:10])  # 显示前10只
    
    # 保存指数成分股到数据库
    db_manager.save_index_stocks(index_code, index_stocks)
    
    # 查询数据库中的股票数据
    print("\n5. 查询数据库中的股票数据")
    db_data = db_manager.get_stock_data(code, start_date, end_date)
    print(f"查询到 {len(db_data)} 条数据记录")
    print(db_data.head())
    
    # 获取数据更新状态
    print("\n6. 获取数据更新状态")
    update_status = db_manager.get_stock_data_update_status()
    print(update_status.head())


def download_hk_stock_data():
    """
    下载港股数据示例
    """
    print("\n===== 下载港股数据示例 =====")
    
    # 创建港股下载器和数据库管理器
    downloader = HKStockDownloader()
    db_manager = HKStockDBManager()
    
    # 获取股票列表
    print("\n1. 获取港股股票列表")
    stock_list = downloader.get_stock_list()
    print(f"获取到 {len(stock_list)} 只港股股票")
    print(stock_list.head())
    
    # 保存股票列表到数据库
    db_manager.save_stock_list(stock_list)
    
    # 下载单只股票数据
    print("\n2. 下载单只港股股票数据（以腾讯控股为例）")
    code = '00700'  # 腾讯控股
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    print(f"下载到 {len(stock_data)} 条数据记录")
    print(stock_data.head())
    
    # 保存股票数据到数据库
    db_manager.save_stock_data(stock_data)
    
    # 下载指数数据
    print("\n3. 下载港股指数数据（以恒生指数为例）")
    index_code = 'HSI'  # 恒生指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    print(f"下载到 {len(index_data)} 条数据记录")
    print(index_data.head())
    
    # 保存指数数据到数据库
    db_manager.save_stock_data(index_data)
    
    # 获取指数成分股
    print("\n4. 获取指数成分股（以恒生指数为例）")
    index_stocks = downloader.get_index_stocks(index_code)
    print(f"获取到 {len(index_stocks)} 只成分股")
    print(index_stocks[:10])  # 显示前10只
    
    # 保存指数成分股到数据库
    db_manager.save_index_stocks(index_code, index_stocks)
    
    # 查询数据库中的股票数据
    print("\n5. 查询数据库中的股票数据")
    db_data = db_manager.get_stock_data(code, start_date, end_date)
    print(f"查询到 {len(db_data)} 条数据记录")
    print(db_data.head())


def download_us_stock_data():
    """
    下载美股数据示例
    """
    print("\n===== 下载美股数据示例 =====")
    
    # 创建美股下载器和数据库管理器
    downloader = USStockDownloader()
    db_manager = USStockDBManager()
    
    # 获取股票列表
    print("\n1. 获取美股股票列表")
    stock_list = downloader.get_stock_list()
    print(f"获取到 {len(stock_list)} 只美股股票")
    print(stock_list.head())
    
    # 保存股票列表到数据库
    db_manager.save_stock_list(stock_list)
    
    # 下载单只股票数据
    print("\n2. 下载单只美股股票数据（以苹果公司为例）")
    code = 'AAPL'  # 苹果公司
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    print(f"下载到 {len(stock_data)} 条数据记录")
    print(stock_data.head())
    
    # 保存股票数据到数据库
    db_manager.save_stock_data(stock_data)
    
    # 下载指数数据
    print("\n3. 下载美股指数数据（以道琼斯工业平均指数为例）")
    index_code = '^DJI'  # 道琼斯工业平均指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    print(f"下载到 {len(index_data)} 条数据记录")
    print(index_data.head())
    
    # 保存指数数据到数据库
    db_manager.save_stock_data(index_data)
    
    # 获取指数成分股
    print("\n4. 获取指数成分股（以道琼斯工业平均指数为例）")
    index_stocks = downloader.get_index_stocks(index_code)
    print(f"获取到 {len(index_stocks)} 只成分股")
    print(index_stocks[:10])  # 显示前10只
    
    # 保存指数成分股到数据库
    db_manager.save_index_stocks(index_code, index_stocks)
    
    # 查询数据库中的股票数据
    print("\n5. 查询数据库中的股票数据")
    db_data = db_manager.get_stock_data(code, start_date, end_date)
    print(f"查询到 {len(db_data)} 条数据记录")
    print(db_data.head())


if __name__ == "__main__":
    # 运行A股数据下载示例
    download_a_stock_data()
    
    # 运行港股数据下载示例
    download_hk_stock_data()
    
    # 运行美股数据下载示例
    download_us_stock_data()