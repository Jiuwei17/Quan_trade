#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
股票数据下载功能测试脚本

验证A股、港股和美股的股票数据下载功能
"""

import os
import sys
from datetime import datetime, timedelta

# 添加项目根目录到系统路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.append(project_root)

# 导入市场数据API
from market_data.downloader.a_stock.a_stock_downloader import AStockDownloader
from market_data.downloader.hk_stock.hk_stock_downloader import HKStockDownloader
from market_data.downloader.us_stock.us_stock_downloader import USStockDownloader
from market_data.database_manager.a_stock_db_manager import AStockDBManager
from market_data.database_manager.hk_stock_db_manager import HKStockDBManager
from market_data.database_manager.us_stock_db_manager import USStockDBManager


def test_a_stock_download():
    """
    测试A股数据下载功能
    """
    print("\n===== 测试A股数据下载功能 =====")
    
    # 创建A股下载器和数据库管理器
    downloader = AStockDownloader()
    db_manager = AStockDBManager()
    
    # 测试获取股票列表
    print("\n1. 测试获取A股股票列表")
    stock_list = downloader.get_stock_list()
    assert len(stock_list) > 0, "获取A股股票列表失败"
    print(f"获取到 {len(stock_list)} 只A股股票")
    
    # 测试下载单只股票数据
    print("\n2. 测试下载单只A股股票数据（以贵州茅台为例）")
    code = '600519'  # 贵州茅台
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    assert len(stock_data) > 0, "下载A股股票数据失败"
    print(f"下载到 {len(stock_data)} 条数据记录")
    
    # 测试下载指数数据
    print("\n3. 测试下载A股指数数据（以上证指数为例）")
    index_code = '000001'  # 上证指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    assert len(index_data) > 0, "下载A股指数数据失败"
    print(f"下载到 {len(index_data)} 条数据记录")


def test_hk_stock_download():
    """
    测试港股数据下载功能
    """
    print("\n===== 测试港股数据下载功能 =====")
    
    # 创建港股下载器和数据库管理器
    downloader = HKStockDownloader()
    db_manager = HKStockDBManager()
    
    # 测试获取股票列表
    print("\n1. 测试获取港股股票列表")
    stock_list = downloader.get_stock_list()
    assert len(stock_list) > 0, "获取港股股票列表失败"
    print(f"获取到 {len(stock_list)} 只港股股票")
    
    # 测试下载单只股票数据
    print("\n2. 测试下载单只港股股票数据（以腾讯控股为例）")
    code = '00700'  # 腾讯控股
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    assert len(stock_data) > 0, "下载港股股票数据失败"
    print(f"下载到 {len(stock_data)} 条数据记录")
    
    # 测试下载指数数据
    print("\n3. 测试下载港股指数数据（以恒生指数为例）")
    index_code = 'HSI'  # 恒生指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    assert len(index_data) > 0, "下载港股指数数据失败"
    print(f"下载到 {len(index_data)} 条数据记录")


def test_us_stock_download():
    """
    测试美股数据下载功能
    """
    print("\n===== 测试美股数据下载功能 =====")
    
    # 创建美股下载器和数据库管理器
    downloader = USStockDownloader()
    db_manager = USStockDBManager()
    
    # 测试获取股票列表
    print("\n1. 测试获取美股股票列表")
    stock_list = downloader.get_stock_list()
    assert len(stock_list) > 0, "获取美股股票列表失败"
    print(f"获取到 {len(stock_list)} 只美股股票")
    
    # 测试下载单只股票数据
    print("\n2. 测试下载单只美股股票数据（以苹果公司为例）")
    code = 'AAPL'  # 苹果公司
    start_date = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
    end_date = datetime.now().strftime('%Y-%m-%d')
    
    stock_data = downloader.download_stock_data(code, start_date, end_date)
    assert len(stock_data) > 0, "下载美股股票数据失败"
    print(f"下载到 {len(stock_data)} 条数据记录")
    
    # 测试下载指数数据
    print("\n3. 测试下载美股指数数据（以道琼斯工业指数为例）")
    index_code = 'DJI'  # 道琼斯工业指数
    index_data = downloader.download_index_data(index_code, start_date, end_date)
    assert len(index_data) > 0, "下载美股指数数据失败"
    print(f"下载到 {len(index_data)} 条数据记录")


if __name__ == '__main__':
    test_a_stock_download()
    test_hk_stock_download()
    test_us_stock_download()