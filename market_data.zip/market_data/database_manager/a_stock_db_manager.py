#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
A股数据库管理器

负责管理A股市场数据的数据库操作，包括股票信息和行情数据的存储和查询。
"""

import os
import sqlite3
import pandas as pd
from datetime import datetime

# 导入基类
from .base_db_manager import BaseDBManager


class AStockDBManager(BaseDBManager):
    """
    A股数据库管理器
    
    负责管理A股市场数据的数据库操作，包括股票信息和行情数据的存储和查询。
    """
    
    def __init__(self, db_dir=None):
        """
        初始化A股数据库管理器
        
        Args:
            db_dir: 数据库目录，如果为None，则使用默认目录
        """
        super().__init__(db_dir)
    
    def get_market_name(self):
        """
        获取市场名称，用于确定数据库目录
        
        Returns:
            str: 市场名称
        """
        return 'a_stock'
    
    def get_latest_trading_date(self, code=None):
        """
        获取最新交易日期
        
        Args:
            code: 股票代码，如果为None，则获取所有股票的最新交易日期
            
        Returns:
            str: 最新交易日期，格式：'YYYY-MM-DD'
        """
        try:
            with sqlite3.connect(self.stock_data_db) as conn:
                cursor = conn.cursor()
                
                if code:
                    # 获取特定股票的最新交易日期
                    cursor.execute(
                        "SELECT MAX(date) FROM daily_data WHERE code = ?",
                        (code,)
                    )
                else:
                    # 获取所有股票的最新交易日期
                    cursor.execute("SELECT MAX(date) FROM daily_data")
                
                result = cursor.fetchone()
                if result and result[0]:
                    return result[0]
                else:
                    return None
                    
        except Exception as e:
            self.logger.error(f"获取最新交易日期失败: {e}")
            return None
    
    def get_stock_codes(self):
        """
        获取所有股票代码
        
        Returns:
            list: 股票代码列表
        """
        try:
            with sqlite3.connect(self.stock_info_db) as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT code FROM stock_info")
                result = cursor.fetchall()
                return [item[0] for item in result]
                
        except Exception as e:
            self.logger.error(f"获取股票代码列表失败: {e}")
            return []
    
    def get_index_codes(self):
        """
        获取所有指数代码
        
        Returns:
            list: 指数代码列表
        """
        # A股主要指数代码
        return ['000001', '399001', '399006', '000300', '000016', '000905', '000852']
    
    def get_stock_info(self, code=None):
        """
        获取股票信息
        
        Args:
            code: 股票代码，如果为None，则获取所有股票信息
            
        Returns:
            DataFrame: 股票信息
        """
        try:
            with sqlite3.connect(self.stock_info_db) as conn:
                if code:
                    # 获取特定股票信息
                    query = "SELECT * FROM stock_info WHERE code = ?"
                    params = (code,)
                else:
                    # 获取所有股票信息
                    query = "SELECT * FROM stock_info"
                    params = None
                
                if params:
                    df = pd.read_sql_query(query, conn, params=params)
                else:
                    df = pd.read_sql_query(query, conn)
                
                return df
                
        except Exception as e:
            self.logger.error(f"获取股票信息失败: {e}")
            return pd.DataFrame()
    
    def get_index_stocks(self, index_code):
        """
        获取指数成分股
        
        Args:
            index_code: 指数代码
            
        Returns:
            list: 成分股代码列表
        """
        try:
            with sqlite3.connect(self.stock_info_db) as conn:
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT stock_code FROM index_stocks WHERE index_code = ?",
                    (index_code,)
                )
                result = cursor.fetchall()
                return [item[0] for item in result]
                
        except Exception as e:
            self.logger.error(f"获取指数成分股失败: {e}")
            return []
    
    def get_stock_data_update_status(self):
        """
        获取股票数据更新状态
        
        Returns:
            DataFrame: 股票数据更新状态，包含股票代码、最新数据日期等信息
        """
        try:
            with sqlite3.connect(self.stock_data_db) as conn:
                # 获取每只股票的最新数据日期
                query = """
                    SELECT code, MAX(date) as latest_date
                    FROM daily_data
                    GROUP BY code
                """
                df = pd.read_sql_query(query, conn)
                
                # 获取股票信息
                stock_info = self.get_stock_info()
                
                # 合并信息
                if not df.empty and not stock_info.empty:
                    result = pd.merge(
                        df,
                        stock_info[['code', 'name']],
                        on='code',
                        how='left'
                    )
                    return result
                else:
                    return df
                
        except Exception as e:
            self.logger.error(f"获取股票数据更新状态失败: {e}")
            return pd.DataFrame()
    
    def get_missing_data_periods(self, code, start_date=None, end_date=None):
        """
        获取缺失数据的时间段
        
        Args:
            code: 股票代码
            start_date: 起始日期，格式：'YYYY-MM-DD'
            end_date: 结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            list: 缺失数据的时间段列表，每个元素为(start_date, end_date)元组
        """
        try:
            # 获取股票在指定时间段内的数据
            data = self.get_stock_data(code, start_date, end_date)
            
            if data.empty:
                # 如果没有数据，则整个时间段都缺失
                if start_date and end_date:
                    return [(start_date, end_date)]
                else:
                    return []
            
            # 将日期转换为datetime对象
            if isinstance(data.index, pd.DatetimeIndex):
                dates = data.index
            else:
                dates = pd.to_datetime(data['date'])
            
            # 按日期排序
            dates = sorted(dates)
            
            # 查找缺失的日期段
            missing_periods = []
            prev_date = None
            
            for date in dates:
                if prev_date is not None:
                    # 检查是否有缺失的日期
                    delta = (date - prev_date).days
                    if delta > 1:
                        # 有缺失的日期
                        missing_start = (prev_date + pd.Timedelta(days=1)).strftime('%Y-%m-%d')
                        missing_end = (date - pd.Timedelta(days=1)).strftime('%Y-%m-%d')
                        missing_periods.append((missing_start, missing_end))
                
                prev_date = date
            
            return missing_periods
            
        except Exception as e:
            self.logger.error(f"获取缺失数据时间段失败: {e}")
            return []