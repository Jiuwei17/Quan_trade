#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
数据库管理器基类

定义所有市场数据库管理器的通用接口和方法，作为各个市场特定数据库管理器的父类。
"""

import os
import logging
import sqlite3
import pandas as pd
from abc import ABC, abstractmethod
from datetime import datetime


class BaseDBManager(ABC):
    """
    数据库管理器基类
    
    定义所有市场数据库管理器的通用接口和方法。
    """
    
    def __init__(self, db_dir=None):
        """
        初始化数据库管理器
        
        Args:
            db_dir: 数据库目录，如果为None，则使用默认目录
        """
        if db_dir is None:
            # 默认数据库目录
            self.db_dir = os.path.join(
                os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                'database',
                self.get_market_name()
            )
        else:
            self.db_dir = db_dir
            
        # 确保数据库目录存在
        os.makedirs(self.db_dir, exist_ok=True)
        
        # 数据库文件路径
        self.stock_info_db = os.path.join(self.db_dir, 'stock_info.db')
        self.stock_data_db = os.path.join(self.db_dir, 'stock_data.db')
        
        # 初始化日志
        self.logger = self._setup_logger()
        
        # 初始化数据库
        self._init_stock_info_db()
        self._init_stock_data_db()
    
    @abstractmethod
    def get_market_name(self):
        """
        获取市场名称，用于确定数据库目录
        
        Returns:
            str: 市场名称，如'a_stock', 'hk_stock', 'us_stock'
        """
        pass
    
    def _setup_logger(self):
        """
        设置日志记录器
        
        Returns:
            Logger: 配置好的日志记录器
        """
        logger = logging.getLogger(f"{self.__class__.__name__}")
        logger.setLevel(logging.INFO)
        
        # 如果没有处理器，添加处理器
        if not logger.handlers:
            # 控制台处理器
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            console_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            console_handler.setFormatter(console_formatter)
            logger.addHandler(console_handler)
            
            # 文件处理器
            log_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
            os.makedirs(log_dir, exist_ok=True)
            file_handler = logging.FileHandler(
                os.path.join(log_dir, f"{self.__class__.__name__.lower()}.log"), 'a'
            )
            file_handler.setLevel(logging.INFO)
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)
        
        return logger
    
    def _init_stock_info_db(self):
        """
        初始化股票信息数据库
        创建股票信息表和指数成分股表
        """
        with sqlite3.connect(self.stock_info_db) as conn:
            cursor = conn.cursor()
            
            # 创建股票信息表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS stock_info (
                    code TEXT,
                    name TEXT,
                    market TEXT,
                    industry TEXT,
                    update_time DATETIME,
                    PRIMARY KEY (code)
                )
            """)
            
            # 创建指数成分股表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS index_stocks (
                    index_code TEXT,
                    stock_code TEXT,
                    update_time DATETIME,
                    PRIMARY KEY (index_code, stock_code)
                )
            """)
            
            conn.commit()
            self.logger.info(f"股票信息数据库初始化完成: {self.stock_info_db}")
    
    def _init_stock_data_db(self):
        """
        初始化股票数据数据库
        创建日线数据表
        """
        with sqlite3.connect(self.stock_data_db) as conn:
            cursor = conn.cursor()
            
            # 创建日线数据表
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS daily_data (
                    code TEXT,
                    date DATE,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    volume REAL,
                    amount REAL,
                    PRIMARY KEY (code, date)
                )
            """)
            
            conn.commit()
            self.logger.info(f"股票数据数据库初始化完成: {self.stock_data_db}")
    
    def save_stock_list(self, stock_list):
        """
        保存股票列表到数据库
        
        Args:
            stock_list: DataFrame，股票列表数据
        """
        if stock_list.empty:
            self.logger.warning("股票列表为空，未保存到数据库")
            return
        
        try:
            # 添加更新时间
            stock_list['update_time'] = datetime.now()
            
            with sqlite3.connect(self.stock_info_db) as conn:
                # 删除旧数据
                cursor = conn.cursor()
                cursor.execute("DELETE FROM stock_info")
                
                # 插入新数据
                stock_list.to_sql(
                    'stock_info',
                    conn,
                    if_exists='append',
                    index=False
                )
                
                self.logger.info(f"股票列表更新成功，共{len(stock_list)}只股票")
                
        except Exception as e:
            self.logger.error(f"保存股票列表失败: {e}")
    
    def save_index_stocks(self, index_code, stock_codes):
        """
        保存指数成分股到数据库
        
        Args:
            index_code: str，指数代码
            stock_codes: list，成分股代码列表
        """
        if not stock_codes:
            self.logger.warning(f"指数{index_code}的成分股列表为空，未保存到数据库")
            return
        
        try:
            # 创建成分股数据框
            index_stocks = pd.DataFrame({
                'index_code': [index_code] * len(stock_codes),
                'stock_code': stock_codes,
                'update_time': [datetime.now()] * len(stock_codes)
            })
            
            with sqlite3.connect(self.stock_info_db) as conn:
                # 删除旧数据
                cursor = conn.cursor()
                cursor.execute(
                    "DELETE FROM index_stocks WHERE index_code = ?",
                    (index_code,)
                )
                
                # 插入新数据
                index_stocks.to_sql(
                    'index_stocks',
                    conn,
                    if_exists='append',
                    index=False
                )
                
                self.logger.info(f"指数{index_code}的成分股更新成功，共{len(stock_codes)}只股票")
                
        except Exception as e:
            self.logger.error(f"保存指数成分股失败: {e}")
    
    def save_stock_data(self, data):
        """
        保存股票数据到数据库
        
        Args:
            data: DataFrame，股票数据
        """
        if data.empty:
            self.logger.warning("股票数据为空，未保存到数据库")
            return
        
        try:
            # 重置索引，将日期列添加到数据中
            if 'date' not in data.columns and data.index.name == 'date':
                data = data.reset_index()
            
            # 确保数据列与数据库表结构匹配
            columns_to_keep = ['date', 'open', 'close', 'high', 'low', 'volume', 'amount', 'code']
            data_to_save = data[columns_to_keep]
            
            # 获取数据范围信息
            min_date = data_to_save['date'].min()
            max_date = data_to_save['date'].max()
            code = data_to_save['code'].iloc[0]
            
            # 转换date列为数据库兼容的字符串格式
            if isinstance(min_date, pd.Timestamp):
                min_date = min_date.strftime('%Y-%m-%d')
                max_date = max_date.strftime('%Y-%m-%d')
                data_to_save['date'] = data_to_save['date'].dt.strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.stock_data_db) as conn:
                # 删除重复数据
                cursor = conn.cursor()
                cursor.execute(
                    "DELETE FROM daily_data WHERE code = ? AND date BETWEEN ? AND ?",
                    (code, min_date, max_date)
                )
                
                # 插入新数据
                data_to_save.to_sql(
                    'daily_data',
                    conn,
                    if_exists='append',
                    index=False
                )
                
                self.logger.info(f"股票{code}的数据更新成功，日期范围: {min_date}至{max_date}，共{len(data_to_save)}条记录")
                
        except Exception as e:
            self.logger.error(f"保存股票数据失败: {e}")
    
    def get_stock_data(self, code, start_date=None, end_date=None):
        """
        从数据库获取股票数据
        
        Args:
            code: str，股票代码
            start_date: str，起始日期，格式：'YYYY-MM-DD'
            end_date: str，结束日期，格式：'YYYY-MM-DD'
            
        Returns:
            DataFrame: 股票数据
        """
        try:
            # 处理日期参数
            if start_date is None:
                start_date = '1990-01-01'
            if end_date is None:
                end_date = datetime.now().strftime('%Y-%m-%d')
            
            with sqlite3.connect(self.stock_data_db) as conn:
                query = """
                    SELECT * FROM daily_data
                    WHERE code = ? AND date BETWEEN ? AND ?
                    ORDER BY date
                """
                
                data = pd.read_sql_query(
                    query,
                    conn,
                    params=(code, start_date, end_date),
                    parse_dates=['date'],
                    index_col='date'
                )
                
                if not data.empty:
                    self.logger.info(f"从数据库获取股票{code}的数据成功，日期范围: {start_date}至{end_date}，共{len(data)}条记录")
                else:
                    self.logger.warning(f"数据库中没有股票{code}在{start_date}至{end_date}范围内的数据")
                
                return data
                
        except Exception as e:
            self.logger.error(f"获取股票数据失败: {e}")
            return pd.DataFrame()
    
    def get_stock_list(self):
        """
        从数据库获取股票列表
        
        Returns:
            DataFrame: 股票列表
        """
        try:
            with sqlite3.connect(self.stock_info_db) as conn:
                query = "SELECT * FROM stock_info"
                
                stock_list = pd.read_sql_query(query, conn)
                
                if not stock_list.empty:
                    self.logger.info(f"从数据库获取股票列表成功，共{len(stock_list)}只股票")
                else:
                    self.logger.warning("数据库中没有股票列表数据")
                
                return stock_list
                
        except Exception as e:
            self.logger.error(f"获取股票列表失败: {e}")
            return pd.DataFrame()
    
    def get_index_stocks(self, index_code):
        """
        从数据库获取指数成分股
        
        Args:
            index_code: str，指数代码
            
        Returns:
            list: 成分股代码列表
        """
        try:
            with sqlite3.connect(self.stock_info_db) as conn:
                query = "SELECT stock_code FROM index_stocks WHERE index_code = ?"
                
                cursor = conn.cursor()
                cursor.execute(query, (index_code,))
                
                stock_codes = [row[0] for row in cursor.fetchall()]
                
                if stock_codes:
                    self.logger.info(f"从数据库获取指数{index_code}的成分股成功，共{len(stock_codes)}只股票")
                else:
                    self.logger.warning(f"数据库中没有指数{index_code}的成分股数据")
                
                return stock_codes
                
        except Exception as e:
            self.logger.error(f"获取指数成分股失败: {e}")
            return pd.DataFrame()